@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0runtime\python.exe" (
    echo Bundled Python was not found: "%~dp0runtime\python.exe"
    pause
    exit /b 1
)
"%~dp0runtime\python.exe" "%~dp0SW\Auto\GUI\QtGUI.py"
if errorlevel 1 (
    echo GUI exited with an error. See the message above.
    pause
    exit /b 1
)
