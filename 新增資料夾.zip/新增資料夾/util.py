import subprocess
import threading
from Auto.Script.Projects.Cobra.Cobra_paramater import *
import re
import ast, json
import os
import time
import struct
import xml.dom.minidom

try:
    from ncclient import manager
    from ncclient.xml_ import to_ele
    NCCLIENT_IMPORT_ERROR = None
except ImportError as exc:
    manager = None
    NCCLIENT_IMPORT_ERROR = exc

    def to_ele(*args, **kwargs):
        raise RuntimeError(
            "ncclient XML helpers are unavailable on this platform. "
            "NETCONF-related Cobra tests must run in a compatible environment."
        ) from NCCLIENT_IMPORT_ERROR

def connect_to_oru(ip=dut_ipv4):
    if manager is None:
        raise RuntimeError(
            "ncclient is unavailable on this Windows environment. "
            "NETCONF-related Cobra tests are not supported here."
        ) from NCCLIENT_IMPORT_ERROR
    for n in range(0, 10):
        try:
            mag = manager.connect(
                host=dut_ipv4,
                port=meta_port,
                username=meta_name,
                password=meta_password,
                hostkey_verify=False,
                timeout=meta_timeout,
                keepalive=meta_keepalive
            )
            print(mag)
            if mag is not None:
                return mag

        except Exception as e:
            print(e)
            time.sleep(2)
            pass


def get_ap_value(log):
    patterns = ["_diff_.*': ", "_pwr_.*': ", "_left_.*': ", "_right_.*': ", "err_status_.*': "]
    back = "},"
    head, tmp_value = (0, 0)
    for pattern in patterns:
        match = re.search(pattern, log)
        if match:
            if pattern == patterns[1]:
                head = match.start() + 9
                break
            elif pattern == patterns[4]:
                head = match.start() + 14
                break
            else:
                head = match.start() + 10
                break
    tmp_value = int(log[head: log.find(back)].strip())
    return tmp_value


def read_log_file(logfile, wait_time=3.0):
    time.sleep(wait_time)
    logfile.seek(logfile.tell())
    return logfile.read()


def test_name_separator(name,log=None,log1=None):
    log.info("Start test case : ########" + str(name))
    log1.info("Start test case : ########" + str(name))


def file_upload(filename):
    cmd = f"""<file-upload xmlns="urn:o-ran:file-management:1.0">
                 <local-logical-file-path>o-ran/log/{filename}</local-logical-file-path>
                 <remote-file-path>sftp://sftp_checker@192.168.2.96:/{sftp_path}/{filename}</remote-file-path>
                 <password>
                     <password>{sftp_pswd}</password>
                 </password>
            </file-upload>"""
    return  cmd


def generate_data(file):
    if os.path.exists(file):
        with open(file, "r") as f:
            data = """<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                          """ + f.read() + """
                      </nc:config>"""
        f.close()
        return data
    else:
        raise AssertionError("file path fail")

def verify_login(logger):
    if len(logger) == 4:
        uart_log, sys_logfile, ap_log, ap_logfile = logger
    elif len(logger) == 3:
        uart_log, sys_logfile, ap_log = logger
        ap_logfile = None
    else:
        raise ValueError(f"Unexpected logger size: {len(logger)}")
    for n in range(0, 3):
        uart_log.uart_write(Setting.Enter.value)
        uart_log.uart_write(Setting.Enter.value)
        main_string = read_log_file(sys_logfile)
        if "login:" in main_string:
            uart_log.uart_write(Setting.LoginName.value, 5)
            uart_log.uart_write(Setting.LoginPassword.value, 5)
        uart_log.uart_write(Setting.Enter.value)
        main_string = read_log_file(sys_logfile)
        if "#" in main_string:
            break

def core_dump_setting(logger):
    uart_log, sys_logfile, ap_log, ap_logfile = logger
    uart_log.uart_write("echo '/tmp/cores/core.%e.%p.%h.%t' > /proc/sys/kernel/core_pattern\n")
    uart_log.uart_write("mkdir -p /tmp/cores\n")
    uart_log.uart_write("ulimit -c unlimited\n")

def unpack_u32(num, abs_on=1, log=None):
    test_logger = log
    test_logger.info(num)
    try:
        if num == 0:
            return num

        elif abs_on == 1:
            u32i_value = struct.pack('I', num)
            u32f_value = struct.unpack('f', u32i_value)
            u32f_value = abs(u32f_value[0])
            test_logger.info("abs ")
            test_logger.info(u32f_value)
            return u32f_value
        elif abs_on == 0:
            u32i_value = struct.pack('I', num)
            u32f_value = struct.unpack('f', u32i_value)
            u32f_value = u32f_value[0]
            test_logger.info(u32f_value)
            return u32f_value
    except Exception:
        assert str(num) + "unpack fail"

def xml_data(cmd):
    try:
        tmp = xml.dom.minidom.parseString(str(cmd))
        tmp_xml = "\n".join([line for line in tmp.childNodes[0].toprettyxml(indent="    ").splitlines() if line.strip()])
        return tmp_xml
    except Exception:
        return cmd

def control_pc_bash(cmd, log=None, wait_time=3.0):
    test_logger = log
    result = subprocess.run(["bash","-c",cmd],capture_output=True,)
    test_logger.info(result.stdout.decode("utf-8"))
    test_logger.info(result.stderr.decode("utf-8"))
    time.sleep(wait_time)

def send_rpc(fun, cmd, opt=None, ele=True, timeout=60, log=None,log1=None):
    netconf_manager = fun
    result = opt
    test_logger = log
    sys_logger = log1
    str_cmd = cmd
    sys_logger.info(cmd)
    test_logger.info("Send : >>>>>>>>>>>>>>>>>>>>" + "\n" + xml_data(cmd))
    sub_enable = False
    for n in range(0, 3):
        try:
            if ele:
                cmd = to_ele(cmd)
            if opt == "dispatch":
                if "create-subscription" in str_cmd:
                    sub_enable = True
                    result = netconf_manager.dispatch(cmd)
                    t = threading.Thread(target=listen_notification, args=(netconf_manager, test_logger, sys_logger),daemon=True)
                    t.start()
                else:
                    result = netconf_manager.dispatch(cmd)
            elif opt == "lock":
                result = netconf_manager.lock(target="running")
            elif opt == "unlock":
                result = netconf_manager.unlock(target="running")
            elif opt == "cap":
                for capability in netconf_manager.server_capabilities:
                    sys_logger.info(capability)
            elif opt == "edit_config":
                result = netconf_manager.edit_config(target='running', config=cmd, default_operation="merge")
            elif opt == "get":
                result = netconf_manager.get(filter=("xpath", cmd))
            elif opt == "take_notification":
                result = netconf_manager.take_notification(timeout=timeout)
                if result != None:
                    result = result.notification_xml
            elif opt == "conf":
                try:
                    result = str(netconf_manager.get_config(source='running'))
                except Exception as e:
                    test_logger.info(e)
                    pass
            elif opt == "close_session":
                try:
                    if sub_enable:
                        t.join()
                    netconf_manager.close_session()
                except Exception as e:
                    test_logger.info(e)
                    pass

            test_logger.info("Receive : <<<<<<<<<<<<<<<<<<<<" + "\n" + xml_data(result))
            sys_logger.info(result)
            return result
        except Exception as e:
            test_logger.info(e)
            pass


def listen_notification(netconf_manager,log=None,log1=None):
    test_logger = log
    sys_logger = log1
    while True:
        try:
            n = netconf_manager.take_notification(timeout=1)
            if n is not None:
                xml = n.notification_xml
                test_logger.info(str(xml))
                sys_logger.info(str(xml))

        except Exception as e:
            test_logger.info(e)
            pass
        time.sleep(0.5)


def return_zip_name(data):
    return data.split("o-ran/log/")[1].split(".zip")[0] + ".zip"

def set_mplane_config(log=None, log1=None):
    """
    JSW-223
    """
    netconf_manager = connect_to_oru()
    test_logger = log
    sys_logger = log1
    for n in range(0, 3):
        try:
            send_rpc(netconf_manager, generate_data(x1), "edit_config", log=test_logger, log1=sys_logger)
            send_rpc(netconf_manager, generate_data(x2), "edit_config", log=test_logger, log1=sys_logger)
            send_rpc(netconf_manager, generate_data(x3), "edit_config", log=test_logger, log1=sys_logger)
            break
        except Exception as e:
            test_logger.info(e)
            if n == 2:
                send_rpc(netconf_manager, Setting.Mplane_close_session.value, "close_session", False, log=test_logger,
                         log1=sys_logger)
                raise AssertionError("mplane_config fail")
    send_rpc(netconf_manager, Setting.Mplane_close_session.value, "close_session", False, log=test_logger,
             log1=sys_logger)

def set_oai_mplane_config(log=None, log1=None):
    """
    JSW-223
    """
    netconf_manager = connect_to_oru()
    test_logger = log
    sys_logger = log1
    for n in range(0, 3):
        try:
            send_rpc(netconf_manager, generate_data(x5), "edit_config", log=test_logger, log1=sys_logger)
            send_rpc(netconf_manager, generate_data(x6), "edit_config", log=test_logger, log1=sys_logger)
            send_rpc(netconf_manager, generate_data(x7), "edit_config", log=test_logger, log1=sys_logger)
            break
        except Exception as e:
            test_logger.info(e)
            if n == 2:
                send_rpc(netconf_manager, Setting.Mplane_close_session.value, "close_session", False, log=test_logger,
                         log1=sys_logger)
                raise AssertionError("mplane_config fail")
    send_rpc(netconf_manager, Setting.Mplane_close_session.value, "close_session", False, log=test_logger,
             log1=sys_logger)

def parse_ipv4_addr(logger, iface="eth0",host="device"):
    uart_log, sys_logfile, ap_log, ap_logfile = logger
    if host == "local":
        local_pc_ip = subprocess.run(["ip", "addr", "show", local_interface], capture_output=True, text=True)
        output = local_pc_ip.stdout
    else:
        uart_log.uart_write(f"ip addr show {iface} | grep 'global dynamic'", 1)
        output = read_log_file(sys_logfile)
    ip_pattern = r"inet (192\.168\.2\.\d+)"
    ip = re.findall(ip_pattern, output)
    assert ip, "ipv4 not found"
    return ip[0] if ip else None

def parse_local_mac(logger, host="local"):
    uart_log, sys_logfile, ap_log, ap_logfile = logger
    local_mac = subprocess.run(["ip", "addr", "show", local_interface], capture_output=True, text=True)
    output = local_mac.stdout
    mac_pattern = r"[0-9a-f]{2}(?::[0-9a-f]{2}){5}"
    mac = re.findall(mac_pattern, output)
    assert mac, "mac not found"
    return mac[0] if mac else None

def update_config_with_jq(logger, config_file, jq_filter):
    uart_log, sys_logfile, ap_log, ap_logfile = logger
    cmd = f"""jq '{jq_filter}' {config_file} > /tmp/tmp_config.json && mv /tmp/tmp_config.json {config_file}"""
    uart_log.uart_write(cmd)

def chk_ptp_status(logger, cmd, status, retries=10, delay=2, interface="eth0"):
    uart_log, sys_logfile, ap_log, ap_logfile = logger
    for i in range(retries):
        if status != "FREERUN":
            uart_log.uart_write(f"mpcli -m get -p splane/ptp-holdover-time", 3)
            uart_log.uart_write(f"ptp2config t i", 3)
            uart_log.uart_write(f"ethtool {interface} | grep 'Link detected'", 1)
            uart_log.uart_write(f"timeout 2s tcpdump -i {interface} -nn -c 1 -vvv 'ether proto 0x88f7'", 2)

        uart_log.uart_write(f"mpcli -m get -p splane/{cmd}")
        main_string = read_log_file(sys_logfile)
        if status in main_string: break
        time.sleep(delay)
    assert re.search(re.escape(status), main_string), f"'{status}' should in '{main_string}'"


def read_text_only(sys_logfile, wait_time=3.0) -> str:
    """Read syslog without python log format"""
    return "\n".join(
        re.compile(r"^\[[^\]]+\]:\s*").sub("", line)
        for line in read_log_file(sys_logfile, wait_time).splitlines()
    )

def get_api_response(sys_logfile, wait_time=3.0, retry=3):
    """
    Parse syslog text into python dict format.
    [Test] Use to extract response of mpcli.
    """
    cleaned_text = read_text_only(sys_logfile, wait_time)

    # Extract text starting with { and ending with }
    match = re.search(r"^\{.*\}", cleaned_text, flags=re.MULTILINE | re.DOTALL)
    dict_str = match.group(0) if match else None
    if dict_str is None and retry > 0:
        return get_api_response(sys_logfile, retry=retry - 1)
    # Safely parse as Python literal
    try:
        return ast.literal_eval(dict_str)
    except (ValueError, SyntaxError):
        return None

def get_json_response(sys_logfile, wait_time=3.0, retry=3):
    """
    Parse syslog text into json format.
    [Test] Use to extract json response of mpcli.
    """
    cleaned_text = read_text_only(sys_logfile, wait_time)

    # Extract the first {...} block (JSON-like) using regex (handles multi-line)
    match = re.search(r"^\{.*\}", cleaned_text, flags=re.MULTILINE | re.DOTALL)
    json_str = match.group(0) if match else None
    if json_str is None and retry > 0:
        return get_json_response(sys_logfile, retry=retry - 1)
    # Parse as json
    try:
        return json.loads(json_str)
    except (ValueError, SyntaxError):
        return None

def parse_interrupt(line: str):
    """Classify interruption and return (left, interrupt, join_with_space)."""
    interrupt_bracket_re = re.compile(r"(.*?)(\[\s{2,}\d+\.\d+\])\s*(.*)")
    interrupt_no_bracket_re = re.compile(r"(.*?)(\s{2,}\d+\.\d+\])\s*(.*)")
    m = interrupt_bracket_re.match(line)
    if m:
        left, _, interrupt = m.groups()
        return left.strip(), _ + " " + interrupt.strip()

    m = interrupt_no_bracket_re.match(line)
    if m:
        left, _, interrupt = m.groups()
        return left.strip(), "[" + _ + " " + interrupt.strip()

    return None, None

def normalize_interrupts(text: str) -> str:
    """
    Handle interrupted log
    eg, Finished    25.225729] stmmaceth 12120000.ethernet eth1: No Safety Features support found
        ;1;39mAccuTime
    """
    ansi_junk_re = re.compile(r";\d+(?:;\d+)*m")
    output = []
    carry = ""
    sub_carry = ""

    for raw_line in text.splitlines():
        line = ansi_junk_re.sub("", raw_line).rstrip()
        leading_bracket_re = re.compile(r"^\s*(\[[^\]]+\])\s*(.*)")
        leading_bracket = ""
        m = leading_bracket_re.match(line)
        if m:
            leading_bracket, line = m.groups()
            line = line.strip()

        left, interrupt = parse_interrupt(line)

        if left is not None:
            carry += leading_bracket + " " + left
            sub_carry += leading_bracket + left
            if interrupt:
                output.append(interrupt)
            continue

        if carry:
            next_str = line.strip()
            sep = "" if carry.endswith(
                " ") or next_str.startswith(" ") else " "
            output.append((leading_bracket + carry +
                          sep + next_str).strip())
            output.append((leading_bracket + sub_carry +
                          sep + next_str).strip())
            if sep == " ":
                output.append((leading_bracket + carry +
                               next_str).strip())
                output.append((leading_bracket + sub_carry +
                               next_str).strip())
            carry = ""
            sub_carry = ""
        else:
            if line.strip():
                output.append(leading_bracket + " " + line.strip())

    if carry:
        output.append(carry.strip())

    return "\n".join(output)

def get_current_version(sys_logfile):
    current_version = None
    main_string = read_text_only(sys_logfile)
    for line in reversed(main_string.splitlines()):
        if "Cobra-SDK" in line and '\\n' in line and '\\l' in line:
            current_version = line.replace('\\n', '').replace('\\l', '')

    version_directory = Path(os.environ.get("TOOL_LOG_DIR", str(Path(__file__).resolve().parent)))
    with open(version_directory / 'test_version', 'w') as version:
        version.write(current_version.rstrip())
    return current_version

def get_file_from_board(logger, test_logger, src_file, dst_file):
    uart_log, sys_logfile, ap_log, ap_logfile = logger
    verify_login(logger)
    # Setup ip on DUT and local, clean old ssh-key and re-add
    uart_log.uart_write(Setting.Interface_sship.value)
    control_pc_bash(Setting.Pc_set_ipv4.value, log=test_logger)
    control_pc_bash(
        f'ssh-keygen -R {dut_ipv4} && ssh-keyscan -H {dut_ipv4} >> ~/.ssh/known_hosts', log=test_logger)

    # Copy file
    cmd = [
        'sshpass', '-p', f'{Setting.LoginPassword.value}',
        'scp',
        f'{Setting.LoginName.value}@{dut_ipv4}:{src_file}',
        'tmp.log'
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    usage = None
    if result.returncode != 0:
        test_logger.info("Error fetching remote file:", result.stderr)
    else:
        test_logger.info(result.stdout)
        test_logger.info(dst_file)
        with open('tmp.log', "rb") as src, open(dst_file, "ab") as dst:
            usage = src.read()
            dst.write(usage)

    # Cleanup
    if os.path.exists("tmp.txt"):
        os.remove('tmp.log')
    return usage if usage is None else usage.decode("utf-8", errors="replace")
