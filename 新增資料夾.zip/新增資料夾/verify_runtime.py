"""Check bundled imports and GUI run/stop/restart without UART hardware."""
import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
# Avoid overwriting a user's HTML report while checking the runtime.
os.environ["PYTEST_ADDOPTS"] = os.environ.get("PYTEST_ADDOPTS", "") + " -p no:reporter"

import importlib
import faulthandler
from pathlib import Path
import tempfile
import time

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / "runtime" / "matplotlib-cache"))

import psutil
from PyQt6.QtWidgets import QApplication
from SW.Auto.GUI import QtGUI as gui_module
from SW.Auto.GUI.QtGUI import PytestGUI, RUNTIME_PYTHON


def wait_until(app, predicate, timeout=30):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        app.processEvents()
        if predicate():
            return
        time.sleep(0.02)
    raise RuntimeError("Timed out waiting for GUI subprocess state")


def main():
    faulthandler.dump_traceback_later(45)
    for name in ("yaml", "serial", "pytest", "numpy", "scipy", "pandas",
                 "matplotlib", "openpyxl", "paramiko", "ncclient.manager",
                 "pymysql", "PIL.Image", "cryptography", "lxml.etree"):
        importlib.import_module(name)
    app = QApplication([])
    gui = PytestGUI()
    # Do not poll physical UART devices during this subprocess lifecycle check.
    gui.com_timer.stop()
    with tempfile.TemporaryDirectory(prefix="qqa-runtime-") as directory:
        directory = Path(directory)
        gui_module.OUTPUT_ROOT = directory / "exports"
        gui_module.TEST_LOG_DIRECTORY = directory / "test_log"
        gui_module.TEST_LOG_DIRECTORY.mkdir()
        (gui_module.TEST_LOG_DIRECTORY / "uart.log").write_text("test log", encoding="utf-8")
        gui.output_name_input.setText("stopped_test")
        marker = directory / "child.pid"
        slow = directory / "test_slow.py"
        slow.write_text(
            "import subprocess, sys, time\n"
            "from pathlib import Path\n"
            "def test_slow():\n"
            "    child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(120)'])\n"
            f"    Path({str(marker)!r}).write_text(str(child.pid))\n"
            "    time.sleep(120)\n", encoding="utf-8")
        gui.test_file = str(slow)
        gui.run_tests()
        try:
            wait_until(app, marker.exists)
            child_pid = int(marker.read_text())
            assert Path(gui.process.program()) == RUNTIME_PYTHON
            gui.stop_test()
            wait_until(app, lambda: gui.process is None and gui.stop_process is None and gui.export_worker is None)
            assert not psutil.pid_exists(child_pid), "Test child process survived stop"
            assert gui.start_button.isEnabled()
            assert (gui_module.OUTPUT_ROOT / "stopped_test/uart.log").read_text() == "test log"
            quick = directory / "test_quick.py"
            quick.write_text("def test_quick():\n    assert True\n", encoding="utf-8")
            gui.test_file = str(quick)
            gui.output_name_input.setText("completed_test")
            gui.run_tests()
            wait_until(app, lambda: gui.process is None and gui.export_worker is None)
            assert "1 passed" in gui.text_edit.toPlainText(), gui.text_edit.toPlainText()
            assert gui.start_button.isEnabled() and not gui.stop_button.isEnabled()
            assert (gui_module.OUTPUT_ROOT / "completed_test/uart.log").read_text() == "test log"
            verify_log_export(app, gui, directory)
        finally:
            if gui.process is not None:
                gui.stop_test()
                wait_until(app, lambda: gui.process is None and gui.stop_process is None and gui.export_worker is None)
            gui.close()
    faulthandler.cancel_dump_traceback_later()
    print("PASS: imports, pytest tree stop/restart, log export, overwrite Yes/No, and folder validation")


def verify_log_export(app, gui, directory):
    source = gui_module.TEST_LOG_DIRECTORY
    (source / "nested/empty").mkdir(parents=True)
    (source / "nested/trace.log").write_text("nested log", encoding="utf-8")
    destination = gui_module.OUTPUT_ROOT / "completed_test"
    (destination / "uart.log").write_text("existing log", encoding="utf-8")
    (destination / "keep.txt").write_text("keep", encoding="utf-8")
    gui.run_output_directory = destination
    original_question = gui_module.QMessageBox.question
    try:
        gui_module.QMessageBox.question = lambda *args: gui_module.QMessageBox.StandardButton.No
        assert not gui.export_test_logs()
        assert (destination / "uart.log").read_text() == "existing log"
        assert not (destination / "nested").exists(), "Cancel must not partially export"
        gui_module.QMessageBox.question = lambda *args: gui_module.QMessageBox.StandardButton.Yes
        assert gui.export_test_logs()
        wait_until(app, lambda: gui.export_worker is None)
        assert (destination / "uart.log").read_text() == "test log"
        assert (destination / "nested/trace.log").read_text() == "nested log"
        assert (destination / "nested/empty").is_dir()
        assert (destination / "keep.txt").read_text() == "keep"
        assert (source / "uart.log").read_text() == "test log"
    finally:
        gui_module.QMessageBox.question = original_question
    for invalid in ("", "..", "../escape", r"C:\other", "bad:name", "CON", "LPT1.txt"):
        try:
            gui_module.output_directory(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Invalid output folder accepted: {invalid}")
    # Path type conflicts must fail before copying.
    conflict = directory / "conflict"
    conflict.mkdir()
    (conflict / "nested").write_text("not a folder", encoding="utf-8")
    try:
        gui_module.log_export_entries(source, conflict)
    except ValueError:
        pass
    else:
        raise AssertionError("File/directory collision was not rejected")


if __name__ == "__main__":
    main()
