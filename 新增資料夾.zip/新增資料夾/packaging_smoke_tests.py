"""Small hardware-free suite also compiled into the release to verify pytest collection."""
import os
from pathlib import Path

import pytest


@pytest.fixture
def number():
    yield 7


def test_native_function(number):
    assert number == 7


class TestNativeClass:
    @pytest.mark.parametrize("value", [1, 2])
    def test_native_method(self, number, value):
        assert number + value in (8, 9)


def test_log_location():
    if "__compiled__" in globals():
        resources = Path(__file__).resolve().parent / "_resources/Auto"
        assert (resources / "Config/auto_config_cobra.yaml").is_file()
        assert (resources / "Script/Projects/Cobra/mplane_hook/ietf-interfaces.xml").is_file()
    from Auto.Lib.Log._log_setting import LOG_DIRECTORY, sys_logger
    directory = Path(os.environ["TOOL_LOG_DIR"])
    assert LOG_DIRECTORY == directory
    sys_logger.info("compiled runtime smoke test")
    assert (directory / "sys_log.txt").is_file()
    from Auto.GUI.QtGUI import LogExportWorker, log_export_entries
    export = directory.parent / "exported-logs"
    worker = LogExportWorker(directory, export, log_export_entries(directory, export), False)
    worker.start()
    worker.join(timeout=10)
    assert not worker.is_alive() and not worker.error
    assert (export / "sys_log.txt").is_file()
    # Release self-test must leave no open log files in its temporary directory.
    from Auto.Lib.Log import _log_setting
    for logger in (_log_setting.test_logger, _log_setting.sys_logger,
                   _log_setting.AP_logger_1, _log_setting.AP_logger_2,
                   _log_setting.AP_logger_3, _log_setting.AP_logger_4):
        for handler in logger.handlers[:]:
            handler.close()
            logger.removeHandler(handler)
