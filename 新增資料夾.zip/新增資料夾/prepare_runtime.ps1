param(
    # Build machine only: CPython 3.12 x64 with pip.
    [string]$BuilderPython = "python"
)
$ErrorActionPreference = "Stop"
$runtimePath = Join-Path $PSScriptRoot "runtime"
$archivePath = Join-Path $PSScriptRoot "python-runtime.zip"
if (Test-Path -LiteralPath $runtimePath) {
    throw "runtime already exists. Move it aside before rebuilding."
}
& $BuilderPython -c "import sys, struct; assert sys.version_info[:2] == (3, 12) and struct.calcsize('P') == 8, 'Use CPython 3.12 x64 to build this runtime'"
if ($LASTEXITCODE -ne 0) { throw "Builder Python validation failed" }
Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip" -OutFile $archivePath
$archiveHash = (Get-FileHash -LiteralPath $archivePath -Algorithm SHA256).Hash
if ($archiveHash -ne "4ACBED6DD1C744B0376E3B1CF57CE906F9DC9E95E68824584C8099A63025A3C3") {
    throw "Python archive checksum mismatch"
}
Expand-Archive -LiteralPath $archivePath -DestinationPath $runtimePath
Set-Content -LiteralPath (Join-Path $runtimePath "python312._pth") -Encoding ascii -Value @(
    "python312.zip", ".", "Lib/site-packages", "..", "../SW", "import site"
)
& $BuilderPython -m pip install --disable-pip-version-check --no-warn-script-location --no-compile --target (Join-Path $runtimePath "Lib/site-packages") -r (Join-Path $PSScriptRoot "SW/Auto/Package/requirements_runtime.lock.txt")
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed" }
& (Join-Path $runtimePath "python.exe") (Join-Path $PSScriptRoot "verify_runtime.py")
if ($LASTEXITCODE -ne 0) { throw "Runtime verification failed" }
Write-Host "Runtime is ready. Launch StartGUI.bat."
