# Build the standalone EXE

## Build requirements

Install full **CPython 3.12 x64 with pip** on the build computer. The embeddable development runtime cannot replace the full build installation.

Double-click `打包.bat` in the project root. It searches for `py -3.12`, then `python`. To select Python explicitly:

```bat
call "打包.bat" "C:\Python312\python.exe"
```

The first build requires internet access to create `.build/venv`, install locked dependencies, and download the MinGW64 compiler. Compilation can take a long time and requires several GB of temporary disk space.

Compiler downloads are cached in `.build/dl` to avoid excessive Windows cache path lengths. A small native compiler probe is built and executed before the full build. Existing official GCC ZIP downloads can be reused.

The batch file runs `build_exe.py`. Check the build Python without downloading or compiling:

```bat
"C:\Python312\python.exe" build_exe.py --check
```

Check or repair the existing build environment without compiling:

```bat
"C:\Python312\python.exe" build_exe.py --check-deps
```

The script checks package imports and installed files. If a critical package such as `ncclient` is missing or damaged, it retries installation once without using the package cache. Diagnostics are saved in `.build/logs/build-dependencies.json`.

Installation clears Python and pip target-directory overrides and ignores pip.ini so packages are installed in `.build/venv`. Use environment variables such as `PIP_INDEX_URL` for a company package index.

## Distribution

A release directory is created only after compilation and the executable self-test succeed:

```text
dist/Tool-<timestamp>/
  Tool.exe
```

- Nuitka onefile includes the GUI, compiled Auto modules, Python, and required libraries.
- Configuration templates, XML files, and other Auto resources are embedded under `_resources/Auto`.
- Distribute only `Tool.exe`. No adjacent runtime, SW, or Auto folder or separate Python installation is required.
- Onefile extracts its execution dependencies and resources to a temporary location when launched.
- The development runtime is not copied into the release directory.
- Native compilation increases the effort required for reverse engineering. It does not provide unbreakable encryption; no commercial encryption license is used.
- Build reports and self-test logs are saved in `.build/logs`. Keep build files and source code out of the distribution.

## Operation and logs

Double-click `Tool.exe`. The interface and application messages are in English.

1. Click **Initialize Configuration** to create `C:\temp\auto_test_config\auto_config_cobra.yaml` if it is missing. Existing configuration is preserved.
2. Select **DutCom** and **DutCom1**, then click **Apply**. COM values are stored as strings while preserving YAML formatting.
3. Enter an **Output folder name**, then click **Run Tests**. The fixed test is `Cobra_LVDS_test_IC`.
4. Click **Stop Tests** to stop pytest and clean up its child processes.

Each run writes its original logs to:

```text
C:\temp\TestTool\work\<run-id>\test_log
```

After completion or process cleanup, the GUI copies all logs to `C:\temp\<output-folder-name>`. Existing filenames trigger an English overwrite confirmation. Selecting **No** cancels the export and preserves the original logs. A new run cannot start while logs are being exported.

The GUI launches the same EXE with `--run-tests`. Its absolute path is captured from `sys.argv[0]`, with `__compiled__.containing_dir` as a fallback, before changing the working directory. Resources are read from the current onefile extraction directory. A custom pytest collector imports compiled test modules; the temporary collector file contains no test implementation.

The build verifies that the release contains only `Tool.exe`, then runs `--launcher-self-test`. This uses the same QProcess launch mechanism as the GUI from an unrelated working directory. Four hardware-free tests cover compiled test functions, classes, fixtures, parametrization, embedded configuration/XML resources, log writing, and background export. Log export uses a Python thread polled by a UI timer.

Startup failures show the executable path and working directory in the output pane. Actual Cobra tests require UART, a DUT, configuration, and any external tools used by the test. Validate hardware operation on the target equipment before distribution.
