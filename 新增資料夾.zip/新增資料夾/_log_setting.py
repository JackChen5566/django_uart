import logging
import os
import shutil
from pathlib import Path
formatter = logging.Formatter('[%(asctime)s - %(levelname)s]: %(message)s')


def setup_logger(name, log_file, level=logging.INFO):
    handler = logging.FileHandler(log_file)
    handler.setFormatter(formatter)
    _logger = logging.getLogger(name)
    _logger.setLevel(level)
    _logger.addHandler(handler)
    return _logger


def regen_logger(path):
    if os.path.exists(path):
        shutil.rmtree(path)
    os.mkdir(path)

def regen_stress_logger(path, prefix):
    os.makedirs(path, exist_ok=True)
    if os.path.exists(path):
        for filename in os.listdir(path):
            full_path = os.path.join(path, filename)
            if prefix == '' or filename.startswith(prefix):
                os.remove(full_path)


if "TOOL_LOG_DIR" not in os.environ:
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
LOG_DIRECTORY = Path(os.environ.get("TOOL_LOG_DIR", "../../test_log"))

PREFIX = ''
if "Cobra_stress_arg" in os.environ:
    PREFIX = f'{os.environ.get("Cobra_stress_arg")}_'
    regen_stress_logger(str(LOG_DIRECTORY), PREFIX)
else:
    if "TOOL_LOG_DIR" in os.environ:
        LOG_DIRECTORY.mkdir(parents=True, exist_ok=True)
    else:
        regen_logger(str(LOG_DIRECTORY))

test_logger = setup_logger(
    "first_logger", LOG_DIRECTORY / f"{PREFIX}auto_test_log.txt")
test_logger.info("Auto test start")

sys_logger = setup_logger(
    "second_logger", LOG_DIRECTORY / f"{PREFIX}sys_log.txt")
sys_logger.info("System log start")

AP_logger_1 = setup_logger(
    "AP_logger_1", LOG_DIRECTORY / f"{PREFIX}ap_log1.txt")
AP_logger_1.info("AP1 log start")

AP_logger_2 = setup_logger(
    "AP_logger_2", LOG_DIRECTORY / f"{PREFIX}ap_log2.txt")
AP_logger_2.info("AP2 log start")

AP_logger_3 = setup_logger(
    "AP_logger_3", LOG_DIRECTORY / f"{PREFIX}ap_log3.txt")
AP_logger_3.info("AP3 log start")

AP_logger_4 = setup_logger(
    "AP_logger_4", LOG_DIRECTORY / f"{PREFIX}ap_log4.txt")
AP_logger_4.info("AP4 log start")

