"""Build a native release using a full CPython 3.12 x64 installation."""
import argparse
import json
from datetime import datetime
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import zipfile

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / ".build"

# Check importable package files, not only pip's installed-package metadata.
DEPENDENCY_PROBE = r'''
import importlib
import importlib.metadata
import importlib.util
import json
from pathlib import Path
import sys

checks = {
    "ncclient==0.6.19": ["ncclient", "ncclient.manager"],
    "Nuitka==2.8.10": ["nuitka"],
    "pytest==8.3.4": ["pytest", "_pytest"],
    "pytest-repeat==0.9.3": ["pytest_repeat"],
    "PyQt6==6.8.1": ["PyQt6", "PyQt6.QtCore", "PyQt6.QtWidgets"],
    "pyserial==3.5": ["serial"],
    "PyYAML==6.0.2": ["yaml"],
}
report = {"python": sys.executable, "prefix": sys.prefix, "paths": sys.path,
          "packages": {}, "broken": {}}
for requirement, modules in checks.items():
    try:
        distribution, expected = requirement.split("==")
        actual = importlib.metadata.version(distribution)
        if actual != expected:
            raise ImportError(f"version {actual}, expected {expected}")
        for name in modules:
            spec = importlib.util.find_spec(name)
            if spec is None or spec.origin is None or not Path(spec.origin).is_file():
                raise ImportError(f"{name}: package source/binary file not found")
            if not Path(spec.origin).resolve().is_relative_to(Path(sys.prefix).resolve()):
                raise ImportError(f"{name}: loaded outside build environment: {spec.origin}")
            importlib.import_module(name)
            report["packages"][name] = spec.origin
    except Exception as error:
        report["broken"][requirement] = f"{type(error).__name__}: {error}"
print(json.dumps(report))
'''


def clean_build_environment():
    env = os.environ.copy()
    for name in ("PYTHONHOME", "PYTHONPATH", "PYTHONUSERBASE",
                 "PIP_TARGET", "PIP_PREFIX", "PIP_USER"):
        env.pop(name, None)
    # Avoid a pip.ini redirecting installations out of the build venv.
    env["PIP_CONFIG_FILE"] = os.devnull
    env["PYTHONNOUSERSITE"] = "1"
    return env


def dependency_report(python, env):
    result = subprocess.run([str(python), "-I", "-c", DEPENDENCY_PROBE],
                            cwd=ROOT, env=env, capture_output=True, text=True,
                            encoding="utf-8", errors="replace", timeout=120)
    if result.returncode:
        raise RuntimeError(f"Build dependency probe failed:\n{result.stdout}\n{result.stderr}")
    try:
        return json.loads(result.stdout)
    except ValueError as error:
        raise RuntimeError(f"Invalid dependency probe output:\n{result.stdout}\n{result.stderr}") from error


def verify_build_dependencies(python, env, log_path):
    report = dependency_report(python, env)
    if report["broken"]:
        print("Repairing missing or damaged build dependencies:", flush=True)
        for requirement, reason in report["broken"].items():
            print(f"  {requirement}: {reason}", flush=True)
        log_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        # Pip can say 'already satisfied' even when cached/package files are missing.
        run([python, "-m", "pip", "install", "--no-user", "--force-reinstall",
             "--no-cache-dir", "--no-deps", *report["broken"]], env=env)
        report = dependency_report(python, env)
    log_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    if report["broken"]:
        details = "\n".join(f"{name}: {reason}" for name, reason in report["broken"].items())
        raise RuntimeError(f"Dependencies are still unavailable; compilation was not started.\n{details}\nDetails: {log_path}")
    print(f"Build Python: {report['python']}", flush=True)
    print(f"ncclient source: {report['packages']['ncclient']}", flush=True)
    return report


def run(command, *, env=None, timeout=None):
    print("+", subprocess.list2cmdline([str(arg) for arg in command]), flush=True)
    subprocess.run([str(arg) for arg in command], cwd=ROOT, env=env, check=True, timeout=timeout)


def validate_builder():
    if sys.platform != "win32" or sys.version_info[:2] != (3, 12) or struct.calcsize("P") != 8:
        raise RuntimeError("Build with full CPython 3.12 x64 on Windows.")
    if (Path(sys.executable).parent / "python312._pth").exists():
        raise RuntimeError("The portable runtime is for running tests. Install full CPython 3.12 x64 to compile.")
    if not (ROOT / "SW/Auto/Script/Projects/Cobra/Cobra_LVDS_test_IC.py").is_file():
        raise RuntimeError("Fixed test suite is missing.")


def copy_resources(destination):
    auto = ROOT / "SW/Auto"
    excluded_directories = {"__pycache__", "test_log", ".pytest_cache", ".git", "GUI"}
    count = 0
    for directory, dirs, files in os.walk(auto):
        dirs[:] = [name for name in dirs if name not in excluded_directories]
        for name in files:
            source = Path(directory) / name
            if source.suffix.lower() in {".py", ".pyc", ".pyo", ".pyd", ".bat", ".ps1"}:
                continue
            if source.is_symlink():
                raise RuntimeError(f"Resource symlinks are not supported: {source}")
            target = destination / "Auto" / source.relative_to(auto)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            count += 1
    return count


def prepare_compiler(python, env):
    """Keep GCC paths short and verify the C toolchain before the expensive build."""
    # GCC constructs include paths with ../ segments; long redirected app caches
    # can exceed Windows path limits even when the normalized header path exists.
    previous_env = env.copy()
    env["NUITKA_CACHE_DIR"] = str(BUILD / "cache")
    env["NUITKA_CACHE_DIR_DOWNLOADS"] = str(BUILD / "dl")
    cache_query = subprocess.run(
        [str(python), "-c", "from nuitka.utils.AppDirs import getCacheDir; print(getCacheDir('downloads'))"],
        cwd=ROOT, env=previous_env, capture_output=True, text=True, check=True)
    old_cache = Path(cache_query.stdout.strip())
    new_cache = BUILD / "dl"
    if old_cache.exists() and old_cache.resolve() != new_cache.resolve():
        for archive in (old_cache / "gcc").rglob("*.zip"):
            if zipfile.is_zipfile(archive):
                target = new_cache / archive.relative_to(old_cache)
                if not target.exists():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(archive, target)
    probe = BUILD / "compiler-probe"
    probe.mkdir(exist_ok=True)
    source = probe / "compiler_probe.py"
    source.write_text("print('compiler-probe-ok')\n", encoding="utf-8")
    run([python, "-m", "nuitka", "--mode=standalone", "--mingw64",
         "--assume-yes-for-downloads", f"--output-dir={probe}",
         "--output-filename=compiler_probe.exe", source], env=env)
    executable = probe / "compiler_probe.dist/compiler_probe.exe"
    result = subprocess.run([str(executable)], cwd=probe, capture_output=True,
                            text=True, check=True, timeout=30)
    if "compiler-probe-ok" not in result.stdout:
        raise RuntimeError("Native compiler probe did not produce expected output")
    print("Native C toolchain probe passed.", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="Validate builder without downloading or compiling")
    parser.add_argument("--check-deps", action="store_true", help="Check/repair existing build venv dependencies without compiling")
    args = parser.parse_args()
    validate_builder()
    if args.check:
        print("Build prerequisites OK (compiler will be acquired by Nuitka).")
        return
    BUILD.mkdir(exist_ok=True)
    logs = BUILD / "logs"
    logs.mkdir(exist_ok=True)
    environment = BUILD / "venv"
    env = clean_build_environment()
    python = environment / "Scripts/python.exe"
    if args.check_deps:
        if not python.is_file():
            raise RuntimeError("Build venv is missing; run the normal build first.")
        verify_build_dependencies(python, env, logs / "build-dependencies.json")
        return
    if not python.exists():
        import venv
        venv.EnvBuilder(with_pip=True).create(environment)
    run([python, "-m", "pip", "install", "--disable-pip-version-check", "--no-user",
         "-r", ROOT / "SW/Auto/Package/requirements_runtime.lock.txt",
         "-r", ROOT / "SW/Auto/Package/requirements_build.txt"], env=env)
    report = verify_build_dependencies(python, env, logs / "build-dependencies.json")
    prepare_compiler(python, env)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    output = BUILD / f"native-{stamp}"
    output.mkdir()
    # Stage only assets, then embed them into onefile instead of shipping a folder.
    resources = output / "resource-data"
    resource_count = copy_resources(resources)
    if not (resources / "Auto/Config/auto_config_cobra.yaml").is_file():
        raise RuntimeError("Configuration template is missing from bundled resources")
    ncclient_site = Path(report["packages"]["ncclient"]).parent.parent
    env["PYTHONPATH"] = os.pathsep.join(map(str, (ROOT / "SW", ROOT, ncclient_site)))
    run([python, "-m", "nuitka", "--mode=onefile", "--mingw64",
         "--assume-yes-for-downloads", "--enable-plugin=pyqt6",
         "--windows-console-mode=hide", "--python-flag=unbuffered",
         "--include-package=Auto", "--include-module=packaged_runner",
         "--include-module=packaging_smoke_tests", "--include-package=pytest",
         "--include-package=_pytest", "--include-module=pytest_repeat",
         "--include-package=ncclient", "--include-package-data=ncclient",
         f"--include-data-dir={resources / 'Auto'}=_resources/Auto",
         f"--output-dir={output}", "--output-filename=Tool.exe",
         f"--report={logs / ('compile-' + stamp + '.xml')}",
         ROOT / "SW/Auto/GUI/QtGUI.py"], env=env)
    executable = output / "Tool.exe"
    if not executable.is_file():
        raise RuntimeError("Compiler did not produce Tool.exe")
    release = output / "release"
    release.mkdir()
    shutil.copy2(executable, release / "Tool.exe")
    if [path.name for path in release.iterdir()] != ["Tool.exe"]:
        raise RuntimeError("Single-file release must contain only Tool.exe")
    self_test_log = logs / f"self-test-{stamp}.log"
    with self_test_log.open("w", encoding="utf-8") as stream:
        subprocess.run([str(release / "Tool.exe"), "--launcher-self-test"],
                       cwd=release, stdout=stream, stderr=subprocess.STDOUT,
                       timeout=180, check=True)
    if "4 passed" not in self_test_log.read_text(encoding="utf-8", errors="replace"):
        raise RuntimeError(f"Compiled pytest collection did not pass all 4 smoke tests: {self_test_log}")
    final_directory = ROOT / "dist" / f"Tool-{stamp}"
    if not release.resolve().is_relative_to(BUILD.resolve()) or not final_directory.resolve().is_relative_to((ROOT / "dist").resolve()):
        raise RuntimeError("Unexpected release path")
    final_directory.parent.mkdir(exist_ok=True)
    release.rename(final_directory)
    print(f"Release ready: {final_directory / 'Tool.exe'}\nEmbedded resources: {resource_count}\nSelf-test: {self_test_log}")
    print("Native compilation raises reverse-engineering cost; it is not unbreakable encryption.")


if __name__ == "__main__":
    try:
        main()
    except (RuntimeError, OSError, subprocess.SubprocessError) as error:
        print(f"BUILD FAILED: {error}", file=sys.stderr)
        raise SystemExit(1)
