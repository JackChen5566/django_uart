"""
Importance: Always update this list if new environment variable is use

List of environment variable use in Cobra_stress.py:
Cobra_stress_arg
cobra_build_number
repeat_count
repeat_count1
repeat_count2
dut_ipv4
vlan_ipv4
DutMac
DutCom
DutCom1
PowerIo
local_interface
local_vlan_interface
pc_ipv4
pc_vlan_ipv4
internet_interface
WgetDailyImage_SysUpgrade
WgetRelase_SysUpgrade
force_oranactive

extra:
board_type
"""

import os
from enum import Enum
from datetime import datetime
from sys import platform
from pathlib import Path
import yaml
import textwrap
path = Path(os.environ["TOOL_AUTO_DIR"]) if "TOOL_AUTO_DIR" in os.environ else Path(__file__).parents[3]
log_directory = Path(os.environ.get("TOOL_LOG_DIR", str(path / 'test_log')))
LogPath = log_directory / 'sys_log.txt'
ApLogPath = log_directory / 'ap_log1.txt'

config = {}
if platform == "linux":
    config_file_path = '/var/auto_test_config/auto_config_cobra.yaml'
    stress_file_path = '/var/auto_test_config/auto_stress_cobra.yaml'
else:
    config_file_path = r'C:\temp\auto_test_config\auto_config_cobra.yaml'
    stress_file_path = r'C:\temp\auto_test_config\auto_stress_cobra.yaml'
gnss_script_path = path / 'Lib' / 'GPS'
repeat_count = 1
repeat_count1 = 10
repeat_count2 = 100
dut_ipv4 = "192.168.9.103"
dut_ipv6 = "2001:db8::9982"
DutMac = "AA:AA:BB:BB:77:68"
DutEth1Mac = "AA:AA:BB:BB:77:55"
DutCom = "/dev/ttyUSB6"
DutCom1 = "/dev/ttyUSB7"
DutCom2 = "/dev/ttyUSB8"
DutCom3 = "/dev/ttyUSB9"
DutCom4 = "/dev/ttyUSB5"
PowerIo = "/dev/ttyUSB10"
Eth_Ctrl = "/dev/ttyUSB10"
rumanager_path = "/etc/rumanager.conf"
zip_name = "sysupgrade_25.01.24.zip"
image_name = "sysupgrade_25.01.24.img"
sftp_path = """home/sftp_group/sftp_checkser/upload"""
sftp_pswd = "123456"
SqlAccount = ""
SqlPassword = ""
local_interface = ""
LocalIP = ""
Eth_port = "eth0"
Eth_port1 = "eth1"
pc_ipv4 = ""
pc_ipv6 = ""
np_interface = ""
dut_ipv4_1 = ""

try:
    with open(config_file_path, 'r') as f:
        config = yaml.safe_load(f)
    repeat_count = config.get('repeat_count', repeat_count)
    repeat_count1 = config.get('repeat_count1', repeat_count1)
    repeat_count2 = config.get('repeat_count2', repeat_count2)
    dut_ipv4 = config.get('dut_ipv4', dut_ipv4)
    dut_ipv4_1 = config.get('dut_ipv4', dut_ipv4)
    vlan_ipv4 = config.get('vlan_ipv4', dut_ipv4)
    DutMac = config.get('DutMac', DutMac)
    DutEth1Mac = config.get('DutEth1Mac', DutEth1Mac)
    DutCom = config.get('DutCom', DutCom)
    DutCom1 = config.get('DutCom1', DutCom1)
    DutCom2 = config.get('DutCom2', DutCom2)
    DutCom3 = config.get('DutCom3', DutCom3)
    DutCom4 = config.get('DutCom4', DutCom4)
    PowerIo = config.get('PowerIo', PowerIo)
    Eth_Ctrl = config.get('Eth_Ctrl', Eth_Ctrl)
    zip_name = config.get('zip_name', zip_name)
    image_name = config.get('image_name', image_name)
    SqlAccount = config.get('SqlAccount', SqlAccount)
    SqlPassword = config.get('SqlPassword', SqlPassword)
    local_interface = config.get('local_interface', local_interface)
    local_vlan_interface = config.get('local_vlan_interface', local_interface)
    dut_ipv6 = config.get('dut_ipv6', dut_ipv6)
    vlan_ipv6 = config.get('vlan_ipv6', dut_ipv6)
    pc_ipv4 = config.get('pc_ipv4', pc_ipv4)
    pc_vlan_ipv4 = config.get('pc_vlan_ipv4', pc_ipv4)
    pc_ipv6 = config.get('pc_ipv6', pc_ipv6)
    pc_vlan_ipv6 = config.get('pc_vlan_ipv6', pc_ipv4)
    np_interface = config.get('np_interface', np_interface)

except Exception as e:
    print(e)
    repeat_count = repeat_count
    repeat_count1 = repeat_count1
    repeat_count2 = repeat_count2
    dut_ipv4 = dut_ipv4
    DutCom = DutCom
    DutCom1 = DutCom1
    DutCom2 = DutCom2
    DutCom3 = DutCom3
    DutCom4 = DutCom4
    PowerIo = PowerIo
    Eth_Ctrl = Eth_Ctrl

Date = datetime.now()
WgetImage_SysUpgrade = 'wget -O /tmp/dir.html http://192.168.2.231:28080/Cobra_dailybuild/ && file=$(tail -n 3 /tmp/dir.html | sed -n \'s/.*>\([^<]*\)<\\/a>.*/\\1/p\') && echo $file && wget -O /tmp/fw.img "http://192.168.2.231:28080/Cobra_dailybuild/$file/dev-image-mt58xx-cobra-{0}.sysimg" && fw-upgrade /tmp/fw.img\n'
WgetDailyImage_SysUpgrade = 'wget -O /tmp/fw.img "http://192.168.2.231:28080/Cobra_dailybuild/{0}/dev-image-mt58xx-cobra-{1}.sysimg" && fw-upgrade /tmp/fw.img\n'
# TODO: relase require another path in 192.168.2.231 to avoid sharepoint auth
WgetRelase_SysUpgrade = 'wget -O /tmp/fw.img "http://192.168.2.231:28080/Cobra_internal_release/{0}/cobra_sdk-{0}.sysimg" && fw-upgrade /tmp/fw.img\n'
meta_name = "oranuser"
meta_password = "metanoia123"
sftp_path = "/home/sftp_group/sftp_checker/upload"
meta_port = 830
meta_timeout= 200
meta_keepalive = 30
hookfilepath = (Path(os.environ["TOOL_AUTO_DIR"]) / "Script/Projects/Cobra/mplane_hook"
                if "TOOL_AUTO_DIR" in os.environ else Path(__file__).resolve().parent / "mplane_hook")
x1 = hookfilepath / "ietf-interfaces.xml"
x2 = hookfilepath / "o-ran-processing-element.xml"
x3 = hookfilepath / "o-ran-uplane-conf-2ccx2ep.xml"
x4 = hookfilepath / "o-ran-uplane-conf-1ccx4ep.xml"
x5 = hookfilepath / "oai-ietf-interfaces.xml"
x6 = hookfilepath / "oai-o-ran-processing-element.xml"
x7 = hookfilepath / "oai-o-ran-uplane-conf.xml"

internet_interface = 'eth0'
sys_usage_log = log_directory / 'top.txt'
sys_temperature_log = log_directory / 'temperature.txt'
force_oranactive = False
# Override parameter with stress setting by environment
if "Cobra_stress_arg" in os.environ:
    env_name = os.environ['Cobra_stress_arg']
    repeat_count = int(os.environ.get(f"{env_name}_repeat_count"))
    repeat_count1 = int(os.environ.get(f"{env_name}_repeat_count1"))
    repeat_count2 = int(os.environ.get(f"{env_name}_repeat_count2"))
    dut_ipv4 = os.environ.get(f"{env_name}_dut_ipv4")
    vlan_ipv4 = os.environ.get(f"{env_name}_vlan_ipv4")
    DutMac = os.environ.get(f"{env_name}_DutMac")
    DutEth1Mac = os.environ.get(f"{env_name}_DutEth1Mac")
    DutCom = os.environ.get(f"{env_name}_DutCom")
    DutCom1 = os.environ.get(f"{env_name}_DutCom1")
    PowerIo = os.environ.get(f"{env_name}_PowerIo")
    local_interface = os.environ.get(f"{env_name}_local_interface")
    local_vlan_interface = os.environ.get(f"{env_name}_local_vlan_interface")
    pc_ipv4 = os.environ.get(f"{env_name}_pc_ipv4")
    pc_vlan_ipv4 = os.environ.get(f"{env_name}_pc_vlan_ipv4")
    LogPath = log_directory / \
        f'{env_name}_sys_log.txt'
    ApLogPath = log_directory / \
        f'{env_name}_ap_log1.txt'
    internet_interface = os.environ.get(f"{env_name}_internet_interface")
    WgetDailyImage_SysUpgrade = os.environ.get(
        f"{env_name}_WgetDailyImage_SysUpgrade")
    WgetRelase_SysUpgrade = os.environ.get(f"{env_name}_WgetRelase_SysUpgrade")
    sys_usage_log = log_directory / f'{env_name}_top.txt'
    sys_temperature_log = log_directory / f'{env_name}_temperature.txt'
    os.environ['board_type'] = os.environ.get(
        "Cobra_stress_arg").split("_", 1)[0].lower()
    force_oranactive = os.environ.get(f"{env_name}_force_oranactive", 'false').lower() == 'true'


class Setting(Enum):
    Enter = "\n"
    LoginName = "root"
    LoginPassword = "12345"
    I2cDetect = "i2cdetect -l"
    Reboot = "reboot"
    Get_ptp_state = "/root/bin/mpcli.py -p splane/ptp-time"
    Oranuser_pwd = "metanoia123"
    Oranuser_pwd_fail = "metanoia1234"
    Ctrl_c = "\x03"
    Netstat_get = "netstat -an | grep 830"
    Ssh_oranuser = "ssh oranuser@" + dut_ipv4 + " -p 830 -s netconf"
    Gen_ssh_key = 'ssh-keygen -f "/root/.ssh/known_hosts" -R "[' + dut_ipv4 + ']:830"\n'
    Ssh_oranuser_fail = "ssh oranuser_fail@" + dut_ipv4 + " -p 830 -s netconf"
    Ssh_oranuser_v6 = "ssh oranuser@" + dut_ipv6 + " -p 830 -s netconf"
    Gen_ssh_key_v6 = 'ssh-keygen -f "/root/.ssh/known_hosts" -R "[' + dut_ipv6 + ']:830"\n'
    Ssh_oranuser_fail_v6 = "ssh oranuser_fail@" + dut_ipv6 + " -p 830 -s netconf"
    MPlane_service = "sysrepocfg -X --xpath /o-ran-sync:sync/* -d operational"
    MPlane_delay_config = "sysrepocfg -m o-ran-delay-management -d operational -X"
    Send_Yes = "yes"
    Rm_image = "rm sysupgrade*"
    Tail_rumanager = "tail -n 30 /var/log/rumanager.log"
    Interface_down = "ifconfig " + Eth_port + " down"
    Interface_mac = "ifconfig " + Eth_port + " hw ether " + DutMac
    Interface_up = "ifconfig " + Eth_port + " up"
    Interface_dhcp = "dhclient " + Eth_port + " -v"
    Interface_sship = "ip addr add " + dut_ipv4 + "/24 dev " + Eth_port
    Interface_check = "ip addr"
    Pc_set_ipv4 = "sudo ip addr add " + pc_ipv4 + "/24 dev  " + local_interface + ""
    Pc_set_ipv6 = "sudo ip -6 addr add "+ pc_ipv6 +"/128 dev  " + local_interface + ""
    Pc_set_ipv6_up = "sudo ip link set " + local_interface + " up"
    Enable_rumanager = "systemctl enable rumanager.service && systemctl start rumanager.service"
    Disable_rumanager = "systemctl stop rumanager.service"
    Check_rumanager = "ps aux | grep rumanager"
    Ru_set_free = f"""sed -i 's/"cali_cfg": *"[^"]*"/"cali_cfg": "0x3f"/' {rumanager_path}"""
    Ru_skip_lock = f"""sed -i 's/"skip_lock":[[:space:]]*\\(true\\|false\\)/"skip_lock": true/' {rumanager_path}"""
    Ru_set_channel = f"""sed -i '/"center-of-channel-bandwidth"/,/\]/ s/[0-9]\\{{10\\}}/3350010000/g' {rumanager_path}"""
    Ru_set_power = f"""sed -i 's/\\("power_detector_type"[[:space:]]*:[[:space:]]*\\)[0-9]\\+/\\12/g' {rumanager_path}"""
    Ru_enable_mplane = f"""sed -i '/"mplane": {{/,/}}/ s/"enable": false/"enable": true/' {rumanager_path}"""
    Ru_disable_mplane = f"""sed -i '/"mplane": {{/,/}}/ s/"enable": true/"enable": false/' {rumanager_path}"""
    Ru_set_mplane_ifce1 = f"""sed -i '/"mplane": {{/,/}}/ s/"interface": "eth0"/"interface": "eth1"/' {rumanager_path}"""
    Ru_set_mplane_ifce0 = f"""sed -i '/"mplane": {{/,/}}/ s/"interface": "eth1"/"interface": "eth0"/' {rumanager_path}"""
    Ru_set_system_gain = f"""sed -i 's/"nominal_system_gain":[[:space:]]*[0-9]\\+/"nominal_system_gain": 181/g' {rumanager_path}"""
    Ru_enable_dsp_log = "sed -i 's/CONSOLE_LOGGER_ENABLED=false/CONSOLE_LOGGER_ENABLED=true/g' /usr/bin/mras_init.sh"
    List_log_folder = "ls /var/log"
    Get_mplane_status = "systemctl status meta-oran-mplaned.service"
    Get_ru_setting = f"""cat {rumanager_path}"""
    Ap_reset = "ap-reset.sh"
    Ap_reset_noskipnp = "ap-reset.sh -o noskipnp"
    Cali_load = "cali-load.sh"
    Cali_save = "cali-save.sh"
    printenv = "fw_printenv"
    factory_reset = "factory-default.sh"
    restart_mplane_service = "systemctl enable meta-oran-mplaned.service && systemctl start meta-oran-mplaned.service"
    AP_IOT_spec_get = "cat /etc/vendorcus.conf"
    Mras_stop = "systemctl stop mras"
    Mras_start = "systemctl start mras"
    Cate_stop = "cate-stop"
    Cate_start = "cate-start"
    Pidstat = "pidstat -u -r"
    Rumanager_status = "systemctl status rumanager"
    Mras_status = "systemctl status mras"
    Dac_gain = (f"""/root/bin/mpcli.py -m get -p ap/mibs -c 00:0E:AD:33:44:00 -i fm1-mac6 -l o_ru_ap_cfg_dac_gain -t int &&
                 /root/bin/mpcli.py -m get -p ap/mibs -c 00:0E:AD:33:44:01 -i fm1-mac2 -l o_ru_ap_cfg_dac_gain -t int &&
                 /root/bin/mpcli.py -m get -p ap/mibs -c 00:0E:AD:33:44:02 -i fm1-mac10 -l o_ru_ap_cfg_dac_gain -t int &&
                 /root/bin/mpcli.py -m get -p ap/mibs -c 00:0E:AD:33:44:03 -i fm1-mac5 -l o_ru_ap_cfg_dac_gain -t int""")
    Cobra_interface_network = f"""ifconfig {Eth_port} down && ifconfig {Eth_port} hw ether {DutMac} && ifconfig {Eth_port} up && udhcpc {Eth_port}"""

    Cobra_network_mac = f"""setenv ethaddr {DutMac}
                            saveenv
                         """

    Cobra_network_eth1_mac = f"""setenv eth1addr {DutEth1Mac}
                            saveenv
                         """
    wdt_disable_systemd_config = textwrap.dedent("""\
    mv /etc/systemd/system.conf.d/99-watchdog.conf /etc/systemd/system.conf.d/20-watchdog.conf.bak
    cat >/etc/systemd/system.conf.d/99-zz-disable-watchdog.conf <<'EOF'
    [Manager]
    RuntimeWatchdogSec=0
    RebootWatchdogSec=0
    EOF
    sync
    reboot
    """)

    trigger_wdt_reboot = textwrap.dedent("""\
    python3 - <<'PY'
    import os, fcntl, struct, time
    WDIOC_SETTIMEOUT = 0xC0045706
    fd = os.open('/dev/watchdog', os.O_WRONLY)
    t = struct.pack('i', 8)
    t = fcntl.ioctl(fd, WDIOC_SETTIMEOUT, t, True)
    print('effective timeout =', struct.unpack('i', t)[0], 'sec')
    time.sleep(600)
    PY
    """)

    Mplane_sub = """ <create-subscription xmlns="urn:ietf:params:xml:ns:netconf:notification:1.0">
                         <stream>NETCONF</stream>
                     </create-subscription>"""

    Mplane_supervision = """<supervision-watchdog-reset xmlns="urn:o-ran:supervision:1.0">
                                <supervision-notification-interval>990</supervision-notification-interval>
                                <guard-timer-overhead>10</guard-timer-overhead>
                            </supervision-watchdog-reset>"""

    Mplane_supervision_1 = """<supervision-watchdog-reset xmlns="urn:o-ran:supervision:1.0">
                                <supervision-notification-interval>60</supervision-notification-interval>
                                <guard-timer-overhead>10</guard-timer-overhead>
                            </supervision-watchdog-reset>"""

    Mplane_report_all = """<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
                               <filter xmlns:o-ran-swm="urn:o-ran:software-management:1.0" type="xpath" select="/o-ran-swm:*//."/>
                               <with-defaults xmlns="urn:ietf:params:xml:ns:yang:ietf-netconf-with-defaults">report-all</with-defaults>
                          </get>"""

    Mplane_report_fm = """<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
                              <filter xmlns:o-ran-fm="urn:o-ran:fm:1.0" type="xpath" select="/o-ran-fm:*//."/>
                              <with-defaults xmlns="urn:ietf:params:xml:ns:yang:ietf-netconf-with-defaults">report-all</with-defaults>
                          </get>"""

    Mplane_report_uplane_conf = """<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
                                       <filter xmlns:o-ran-uplane-conf="urn:o-ran:uplane-conf:1.0" type="xpath" select="/o-ran-uplane-conf:*//."/>
                                       <with-defaults xmlns="urn:ietf:params:xml:ns:yang:ietf-netconf-with-defaults">report-all</with-defaults>
                                   </get>"""

    Mplane_custom_alarm = """<set-alarm xmlns="urn:mta:ru-manager:1.0">
                                 <fault-id>17</fault-id>
                                 <fault-text>Custom Alarm!Custom Alarm!Custom Alarm!</fault-text>
                                 <is-cleared>false</is-cleared>
                             </set-alarm>"""

    Mplane_custom_alarm_clear = """<set-alarm xmlns="urn:mta:ru-manager:1.0">
                                 <fault-id>17</fault-id>
                                 <fault-text>Custom Alarm!Custom Alarm!Custom Alarm!</fault-text>
                                 <is-cleared>true</is-cleared>
                             </set-alarm>"""

    Mplane_troubleshooting = """<start-troubleshooting-logs xmlns="urn:o-ran:troubleshooting:1.0"/>"""

    Mplane_trace = """<start-trace-logs xmlns="urn:o-ran:trace:1.0"/>"""

    Mplane_trace_stop = """<stop-trace-logs xmlns="urn:o-ran:trace:1.0"/>"""

    Mplane_close_session = """<close-session xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"/>"""

    Mplane_install_negative_1 = """<software-download xmlns="urn:o-ran:software-management:1.0">
                                       <remote-file-path>sftp://sftp_checker@192.168.2.96:/home/sftp_group/sftp_checker/upload/test_negative_cobra.zip</remote-file-path>
                                       <password><password>12345</password></password>
                                   </software-download>"""

    Mplane_install_negative_2 = """<software-download xmlns="urn:o-ran:software-management:1.0">
                                       <remote-file-path>sftp://sftp_checker@192.168.2.96:/home/sftp_group/sftp_checker/upload/test_negative.zip</remote-file-path>
                                       <password><password>123456</password></password>
                                   </software-download>"""

    Mplane_install_positive = f"""<software-download xmlns="urn:o-ran:software-management:1.0">
                                      <remote-file-path>sftp://sftp_checker@192.168.2.96:/home/sftp_group/sftp_checker/upload/{zip_name}</remote-file-path>
                                      <password><password>123456</password></password>
                                 </software-download>"""

    Mplane_install_slot0 = f"""<software-install xmlns="urn:o-ran:software-management:1.0">
                                   <slot-name>slot0</slot-name>
                                   <file-names>{image_name}</file-names>
                               </software-install>"""

    Mplane_install_slot1 = f"""<software-install xmlns="urn:o-ran:software-management:1.0">
                                   <slot-name>slot1</slot-name>
                                   <file-names>{image_name}</file-names>
                               </software-install>"""

    Mplane_active_slot0 = """<software-activate xmlns="urn:o-ran:software-management:1.0">
                                 <slot-name>slot0</slot-name>
                             </software-activate>"""

    Mplane_active_slot1 = """<software-activate xmlns="urn:o-ran:software-management:1.0">
                                 <slot-name>slot1</slot-name>
                             </software-activate>"""

    Mplane_notification = """<notification xmlns="urn:ietf:params:xml:ns:netconf:notification:1.0">
                             </notification>"""

    Mplane_usermgmt = """<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
                             <filter xmlns:o-ran-usermgmt="urn:o-ran:user-mgmt:1.0" type="xpath" select="/o-ran-usermgmt:*//."/>
                             <with-defaults xmlns="urn:ietf:params:xml:ns:yang:ietf-netconf-with-defaults">report-all</with-defaults>
                         </get>"""

    Mplane_sync_status = """<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
                                <filter type="subtree">
                                     <sync xmlns="urn:o-ran:sync:1.0">
                                         <sync-status/>
                                     </sync>
                                </filter>
                            </get>"""

    Mplane_interface_all = """<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0">
                                  <filter xmlns:if="urn:ietf:params:xml:ns:yang:ietf-interfaces" type="xpath" select="/if:*//."/>
                                  <with-defaults xmlns="urn:ietf:params:xml:ns:yang:ietf-netconf-with-defaults">report-all</with-defaults>
                              </get>"""

    Mplane_set_user = """<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                            <users xmlns="urn:o-ran:user-mgmt:1.0">
                                <user>
                                    <name>oranuser2</name>
                                   <password>o-ran-password2</password>
                                   <enabled>true</enabled>
                                </user>
                                <user>
                                   <name>oranuser3</name>
                                   <password>o-ran-password3</password>
                                   <enabled>true</enabled>
                                </user>
                            </users>
                          </nc:config>"""

    Mplane_set_user_group = """<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                                    <nacm xmlns="urn:ietf:params:xml:ns:yang:ietf-netconf-acm">
                                        <groups>
                                            <group>
                                              <name>nms</name>
                                              <user-name>nmsuser</user-name>
                                              <user-name>oranuser2</user-name>
                                              <user-name>oranuser3</user-name>
                                            </group>
                                            <group>
                                              <name>fm-pm</name>
                                              <user-name>fmpmuser</user-name>
                                            </group>
                                            <group>
                                              <name>swm</name>
                                              <user-name>swmuser</user-name>
                                            </group>
                                            <group>
                                              <name>smo</name>
                                              <user-name>smouser</user-name>
                                            </group>
                                            <group>
                                              <name>hybrid-odu</name>
                                              <user-name>hybridoduuser</user-name>
                                            </group>
                                            <group>
                                              <name>sudo</name>
                                              <user-name>oranuser</user-name>
                                            </group>
                                        </groups>
                                  </nacm>
                              </nc:config>"""

    mplane_configurability_1 = f"""<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                                        <interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces" xmlns:oif="urn:o-ran:interfaces:1.0" xmlns:ip="urn:ietf:params:xml:ns:yang:ietf-ip">
                                            <interface>
                                                <name>eth0</name>
                                                <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">ianaift:ethernetCsmacd</type>
                                                <oif:l2-mtu>9000</oif:l2-mtu>
                                                <mac-address xmlns="urn:o-ran:interfaces:1.0">{DutMac}</mac-address>
                                                <oif:vlan-tagging>true</oif:vlan-tagging>
                                                <oif:class-of-service>
                                                    <oif:u-plane-marking>7</oif:u-plane-marking>
                                                    <oif:c-plane-marking>7</oif:c-plane-marking>
                                                    <oif:m-plane-marking>2</oif:m-plane-marking>
                                                </oif:class-of-service>
                                                <oif:port-reference>
                                                    <oif:port-number>0</oif:port-number>
                                                </oif:port-reference>
                                            </interface>
                                            <interface>
                                                <name>vlan3</name>
                                                <type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">ianaift:l2vlan</type>
                                                <enabled>true</enabled>
                                                <mac-address xmlns="urn:o-ran:interfaces:1.0">{DutMac}</mac-address>
                                                <base-interface xmlns="urn:o-ran:interfaces:1.0">eth0</base-interface>
                                                <vlan-id xmlns="urn:o-ran:interfaces:1.0">3</vlan-id>
                                            </interface>
                                        </interfaces>
                                    </nc:config>"""

    mplane_configurability_2 = """<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                                        <md-data-definitions xmlns="urn:o-ran:lbm:1.0">
                                            <maintenance-domain>
                                                <id>KEYS_xyz_LBM</id>
                                                <name>level_7</name>
                                                <md-level>7</md-level>
                                            </maintenance-domain>
                                        </md-data-definitions>
                                </nc:config>"""

    mplane_configurability_3 = """<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                                    <mplane-info xmlns="urn:o-ran:mplane-interfaces:1.0">
                                        <searchable-mplane-access-vlans-info>
                                            <vlan-range>
                                                <lowest-vlan-id>1</lowest-vlan-id>
                                                <highest-vlan-id>1</highest-vlan-id>
                                            </vlan-range>
                                        </searchable-mplane-access-vlans-info>
                                        <m-plane-interfaces>
                                            <m-plane-ssh-ports/>
                                        </m-plane-interfaces>
                                    </mplane-info>
                                </nc:config>"""

    mplane_configurability_4 = f"""<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                                        <processing-elements xmlns="urn:o-ran:processing-element:1.0" nc:operation="merge">
                                         <transport-session-type>ETH-INTERFACE</transport-session-type>
                                         <ru-elements>
                                            <name>pse3</name>
                                            <transport-flow>
                                               <interface-name>vlan3</interface-name>
                                               <eth-flow>
                                                  <ru-mac-address>{DutMac}</ru-mac-address>
                                                  <vlan-id>3</vlan-id>
                                                  <o-du-mac-address>00:11:22:33:44:55</o-du-mac-address>
                                               </eth-flow>
                                            </transport-flow>
                                         </ru-elements>
                                      </processing-elements>
                                  </nc:config>"""

    mplane_configurability_5 = """<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                                        <user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0">
                                            <low-level-tx-endpoints>
                                                <name>tx-ep0</name>
                                                <compression>
                                                  <iq-bitwidth>9</iq-bitwidth>
                                                  <compression-type>DYNAMIC</compression-type>
                                                  <exponent>4</exponent>
                                                  <dynamic-compression-configuration>
                                                    <id>0</id>
                                                    <iq-bitwidth>9</iq-bitwidth>
                                                    <compression-method>BLOCK_FLOATING_POINT</compression-method>
                                                    <fs-offset>0</fs-offset>
                                                  </dynamic-compression-configuration>
                                                </compression>
                                                <frame-structure>161</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>9</eaxc-id>
                                                </e-axcid>
                                              </low-level-tx-endpoints>
                                              <low-level-rx-endpoints>
                                                <name>rx-ep0</name>
                                                <compression>
                                                  <iq-bitwidth>9</iq-bitwidth>
                                                  <compression-type>DYNAMIC</compression-type>
                                                  <exponent>4</exponent>
                                                  <dynamic-compression-configuration>
                                                    <id>0</id>
                                                    <iq-bitwidth>9</iq-bitwidth>
                                                    <compression-method>BLOCK_FLOATING_POINT</compression-method>
                                                    <fs-offset>0</fs-offset>
                                                  </dynamic-compression-configuration>
                                                </compression>
                                                <frame-structure>161</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <ul-fft-sampling-offsets>
                                                  <scs>KHZ_30</scs>
                                                  <ul-fft-sampling-offset>21</ul-fft-sampling-offset>
                                                </ul-fft-sampling-offsets>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>9</eaxc-id>
                                                </e-axcid>
                                                <non-time-managed-delay-enabled>false</non-time-managed-delay-enabled>
                                              </low-level-rx-endpoints>
                                              <low-level-rx-endpoints>
                                                <name>rx-ep1</name>
                                                <compression>
                                                  <iq-bitwidth>9</iq-bitwidth>
                                                  <compression-type>DYNAMIC</compression-type>
                                                  <exponent>4</exponent>
                                                  <dynamic-compression-configuration>
                                                    <id>0</id>
                                                    <iq-bitwidth>9</iq-bitwidth>
                                                    <compression-method>BLOCK_FLOATING_POINT</compression-method>
                                                    <fs-offset>0</fs-offset>
                                                  </dynamic-compression-configuration>
                                                </compression>
                                                <frame-structure>161</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <ul-fft-sampling-offsets>
                                                  <scs>KHZ_30</scs>
                                                  <ul-fft-sampling-offset>21</ul-fft-sampling-offset>
                                                </ul-fft-sampling-offsets>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>10</eaxc-id>
                                                </e-axcid>
                                                <non-time-managed-delay-enabled>false</non-time-managed-delay-enabled>
                                              </low-level-rx-endpoints>
                                            </user-plane-configuration>
                                        </nc:config>"""

    mplane_configurability_duplate = """<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0">
                                         <user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0">
                                              <low-level-rx-endpoints>
                                                <name>rx-ep3</name>
                                                <compression>
                                                  <compression-type>STATIC</compression-type>
                                                  <bitwidth>14</bitwidth>
                                                  <exponent>4</exponent>
                                                </compression>
                                                <frame-structure>193</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <ul-fft-sampling-offsets>
                                                  <scs>KHZ_30</scs>
                                                  <ul-fft-sampling-offset>21</ul-fft-sampling-offset>
                                                </ul-fft-sampling-offsets>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>0</eaxc-id>
                                                </e-axcid>
                                                <non-time-managed-delay-enabled>false</non-time-managed-delay-enabled>
                                              </low-level-rx-endpoints>
                                              <low-level-rx-endpoints>
                                                <name>prach-ep0</name>
                                                <compression>
                                                  <compression-type>STATIC</compression-type>
                                                  <bitwidth>14</bitwidth>
                                                  <exponent>4</exponent>
                                                </compression>
                                                <frame-structure>193</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <ul-fft-sampling-offsets>
                                                  <scs>KHZ_30</scs>
                                                  <ul-fft-sampling-offset>21</ul-fft-sampling-offset>
                                                </ul-fft-sampling-offsets>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>0</eaxc-id>
                                                </e-axcid>
                                                <non-time-managed-delay-enabled>false</non-time-managed-delay-enabled>
                                              </low-level-rx-endpoints>
                                              <low-level-rx-endpoints>
                                                <name>prach-ep1</name>
                                                <compression>
                                                  <compression-type>STATIC</compression-type>
                                                  <bitwidth>14</bitwidth>
                                                  <exponent>4</exponent>
                                                </compression>
                                                <frame-structure>193</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <ul-fft-sampling-offsets>
                                                  <scs>KHZ_30</scs>
                                                  <ul-fft-sampling-offset>21</ul-fft-sampling-offset>
                                                </ul-fft-sampling-offsets>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>0</eaxc-id>
                                                </e-axcid>
                                                <non-time-managed-delay-enabled>false</non-time-managed-delay-enabled>
                                              </low-level-rx-endpoints>
                                              <low-level-rx-endpoints>
                                                <name>prach-ep2</name>
                                                <compression>
                                                  <compression-type>STATIC</compression-type>
                                                  <bitwidth>14</bitwidth>
                                                  <exponent>4</exponent>
                                                </compression>
                                                <frame-structure>193</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <ul-fft-sampling-offsets>
                                                  <scs>KHZ_30</scs>
                                                  <ul-fft-sampling-offset>21</ul-fft-sampling-offset>
                                                </ul-fft-sampling-offsets>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>0</eaxc-id>
                                                </e-axcid>
                                                <non-time-managed-delay-enabled>false</non-time-managed-delay-enabled>
                                              </low-level-rx-endpoints>
                                            <low-level-rx-endpoints>
                                                <name>prach-ep3</name>
                                                <compression>
                                                  <compression-type>STATIC</compression-type>
                                                  <bitwidth>14</bitwidth>
                                                  <exponent>4</exponent>
                                                </compression>
                                                <frame-structure>193</frame-structure>
                                                <cp-type>NORMAL</cp-type>
                                                <cp-length>88</cp-length>
                                                <cp-length-other>72</cp-length-other>
                                                <offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center>
                                                <number-of-prb-per-scs>
                                                  <scs>KHZ_30</scs>
                                                  <number-of-prb>273</number-of-prb>
                                                </number-of-prb-per-scs>
                                                <ul-fft-sampling-offsets>
                                                  <scs>KHZ_30</scs>
                                                  <ul-fft-sampling-offset>21</ul-fft-sampling-offset>
                                                </ul-fft-sampling-offsets>
                                                <e-axcid>
                                                  <o-du-port-bitmask>49152</o-du-port-bitmask>
                                                  <band-sector-bitmask>16128</band-sector-bitmask>
                                                  <ccid-bitmask>240</ccid-bitmask>
                                                  <ru-port-bitmask>15</ru-port-bitmask>
                                                  <eaxc-id>0</eaxc-id>
                                                </e-axcid>
                                                <non-time-managed-delay-enabled>false</non-time-managed-delay-enabled>
                                              </low-level-rx-endpoints>
                                              </user-plane-configuration>
                                        </nc:config>
                                    """

class VerifyPattern(Enum):
    watchdog = "watchdog did not stop!"
    powerOn = "Cobra-SDK "
    ptp_synced = "'synchronized': 'YES'"
    ptp_not_synced = "'synchronized': 'NO'"
    netconf_patten = "urn:ietf:params:xml:ns:netconf"
    password = "password"
    listen = "LISTEN"
    fingerprint = "fingerprint"
    host_change = "REMOTE HOST IDENTIFICATION HAS CHANGED"
    dac_value = "15"
    mplane_ok = "<ok/></rpc-reply>"
    mplane_supervision = "supervision"
    mplane_interfaces = "interfaces"
    mplane_uplane_conf = "urn:o-ran:uplane-conf"
    mplane_sync_status = "sync-status"
    mplane_completed = "COMPLETED"
    mplane_started = "STARTED"
    mplane_slot = "software-slot"
    mplane_application_error = "APPLICATION_ERROR"
    mplane_authentication_error = "AUTHENTICATION_ERROR"
    mplane_file_error = "FILE_ERROR"
    mplane_callback_error = "error:"
    mplane_success = "SUCCESS"
    mplane_alarm_notif = "alarm-notif"
    mplane_permission_denied = "Permission denied"
    mplane_capability = "capability"
    mras_power_up = "powering up mras"
    mras_now_up = "mras is now up"
    Not_specified_error = "error"
    ALLOWED_TCP = ["22/tcp", "830/tcp", "8374/tcp", "8375/tcp", "8373/tcp"]
    ALLOWED_DYNAMIC = 2
    ALLOWED_UDP = ["68/udp"]
    active_status = "Active: active (running)"
    inactive_status = "(dead)"
    # From ruap.py
    VALID_MIBS_LEAFS = ["o_ru_manage_heartbeat_stat", "o_ru_manage_stat", "o_ru_splane_stat",
                   "o_ru_manage_cmd", "oran_mplane_low_lvl_tx_ep_frm_struct",
                   "oran_mplane_low_lvl_rx_ep_frm_struct", "o_ru_rf_cfg_trxsw_set_prekick",
                   "o_ru_rf_cfg_rf_mapping_order", "oran_mplane_rx_array_carrier_n_ta_off",
                   "oran_mplane_tx_array_carrier_ref_lvl_0",
                   "oran_mplane_low_lvl_tx_ep_comp_type",
                   "oran_mplane_low_lvl_tx_ep_comp_format_0", "oran_mplane_low_lvl_tx_ep_iq_bw",
                   "oran_mplane_low_lvl_rx_ep_comp_type", "oran_mplane_low_lvl_rx_ep_iq_bw",
                   "oran_mplane_low_lvl_rx_ep_comp_format_0", "oran_mplane_proc_elem_vlan_id",
                   "oran_mplane_proc_elem_vlan_pcp", "oran_mplane_proc_elem_vlan_pcp_prach",
                   "oran_mplane_proc_elem_ru_mac_addr_0", "oran_mplane_proc_elem_ru_mac_addr_1",
                   "oran_mplane_proc_elem_ru_mac_addr_2", "oran_mplane_proc_elem_ru_mac_addr_3",
                   "oran_mplane_proc_elem_ru_mac_addr_4", "oran_mplane_proc_elem_ru_mac_addr_5",
                   "oran_mplane_tx_array_carrier_carr_act_0", "oran_mplane_tx_array_carrier_carr_act_15",
                   "oran_mplane_rx_array_carrier_carr_act_0", "oran_mplane_rx_array_carrier_carr_act_31",
                   "oran_mplane_proc_elem_l2_mtu",
                   "o_ru_rf_cfg_pa_set_prekick", "o_ru_splane_pps_switch", "o_ru_splane_alpha",
                   "o_ru_splane_beta", "o_ru_rf_cfg_pa_set_prekick", "o_ru_rf_cfg_num_rf_card",
                   "o_ru_ap_capability_dl_cp_min", "o_ru_ap_capability_dl_cp_max",
                   "o_ru_ap_capability_dl_up_min", "o_ru_ap_capability_dl_up_max",
                   "o_ru_ap_capability_ul_cp_min", "o_ru_ap_capability_ul_cp_max",
                   "o_ru_ap_capability_ul_pkt_delay", "o_ru_ap_capability_act_power_step_size",
                   "o_ru_ap_capability_act_power_step_max", "o_ru_ap_cfg_nic_addr",
                   "o_ru_DPD_config_auto_search_try_max", "o_ru_DPD_config_auto_search_npolys",
                   "o_ru_DPD_config_auto_search_delay_max",
                   "o_ru_DPD_config_auto_search_ord_max", "o_ru_DPD_config_auto_search_rng_seed",
                   "o_ru_DPD_config_iterations", "o_ru_DPD_config_converge_iters",
                   "o_ru_DPD_config_init_step_size", "o_ru_DPD_config_stable_step_size",
                   "o_ru_DPD_config_active_step_size", "o_ru_DPD_config_rx_eq_taps_flag",
                   "o_ru_DPD_config_loopback_papar_max", "o_ru_DPD_config_debug_print",
                   "o_ru_splane_cmd", "o_ru_splane_gps_sec", "o_ru_splane_gps_dlt",
                   "o_ru_DPD_config_auto_search_finish_0",
                   "o_ru_DPD_config_auto_search_finish_1", "o_ru_manage_pcap_addr",
                   "o_ru_manage_pcap_dl_size", "o_ru_manage_pcap_pkt_offset",
                   "o_ru_rf_cfg_board_cfg_0", "o_ru_rf_cfg_tx_pin_cfg_0",
                   "o_ru_rf_cfg_rx_pin_cfg_0", "o_ru_rf_cfg_txloss_0",
                   "o_ru_rf_cfg_power_detector_type_0", "o_ru_rf_cfg_lna_gain_0",
                   "o_ru_rf_cfg_rf_if_0", "o_ru_rf_cfg_board_cfg_1",
                   "o_ru_rf_cfg_tx_pin_cfg_1", "o_ru_rf_cfg_rx_pin_cfg_1",
                   "o_ru_rf_cfg_txloss_1", "o_ru_rf_cfg_power_detector_type_1",
                   "o_ru_rf_cfg_lna_gain_1", "o_ru_rf_cfg_rf_if_1",
                   "oran_mplane_rx_array_carrier_gn_crr_0", "oran_mplane_tx_array_carrier_gn_0",
                   "oran_mplane_tx_array_carrier_ch_bw_0",
                   "oran_mplane_tx_array_carrier_cnt_ch_bw_0", "o_ru_rf_cfg_if_carrier_freq_0",
                   "oran_mplane_rx_array_carrier_gn_crr_1", "oran_mplane_tx_array_carrier_gn_1",
                   "oran_mplane_tx_array_carrier_ch_bw_1",
                   "oran_mplane_tx_array_carrier_cnt_ch_bw_1",
                   "o_ru_rf_cfg_if_carrier_freq_1", "oran_mplane_low_lvl_tx_ep_eaxc_id_0",
                   "oran_mplane_low_lvl_rx_ep_eaxc_id_0", "oran_mplane_low_lvl_tx_ep_eaxc_id_1",
                   "oran_mplane_low_lvl_rx_ep_eaxc_id_1", "oran_mplane_low_lvl_tx_ep_eaxc_id_2",
                   "oran_mplane_low_lvl_rx_ep_eaxc_id_2", "oran_mplane_low_lvl_tx_ep_eaxc_id_3",
                   "oran_mplane_low_lvl_rx_ep_eaxc_id_3", "o_ru_ap_cfg_re_offset_0",
                   "o_ru_ap_cfg_re_offset_1", "o_ru_ap_cfg_tx_gain_correction_0",
                   "o_ru_ap_cfg_tx_gain_correction_1", "o_ru_ap_cfg_tx_gain_correction_2",
                   "o_ru_ap_cfg_tx_gain_correction_3", "o_ru_ap_cfg_rx_gain_correction_0",
                   "o_ru_ap_cfg_rx_gain_correction_1", "o_ru_ap_cfg_rx_gain_correction_2",
                   "o_ru_ap_cfg_rx_gain_correction_3", "o_ru_rf_cfg_tx_gain_manual_0",
                   "o_ru_rf_cfg_tx_gain_manual_1", "o_ru_rf_cfg_tx_gain_manual_2",
                   "o_ru_rf_cfg_tx_gain_manual_3", "o_ru_rf_cfg_rx_gain_manual_0",
                   "o_ru_rf_cfg_rx_gain_manual_1", "o_ru_rf_cfg_rx_gain_manual_2",
                   "o_ru_rf_cfg_rx_gain_manual_3", "o_ru_rf_cfg_tx_fine_gain_manual_0",
                   "o_ru_rf_cfg_tx_fine_gain_manual_1", "o_ru_rf_cfg_tx_fine_gain_manual_2",
                   "o_ru_rf_cfg_tx_fine_gain_manual_3", "o_ru_cal_cfg_flags",
                   "o_ru_cal_rx_dc_average_number", "o_ru_cal_auxadc_poly_coeffs_p0_p1_0",
                   "o_ru_cal_auxadc_poly_coeffs_p0_p1_1", "o_ru_cal_auxadc_poly_coeffs_p0_p1_2",
                   "o_ru_cal_auxadc_poly_coeffs_p0_p1_3", "o_ru_cal_rf_rx_loss_0",
                   "o_ru_cal_rf_rx_loss_1", "o_ru_cal_rf_rx_loss_2", "o_ru_cal_rf_rx_loss_3",
                   "o_ru_ap_capability_tx_rf_gain_max_0", "o_ru_ap_capability_tx_rf_gain_max_1",
                   "o_ru_DPD_config_poly_struct_0", "o_ru_rf_cfg_dpd_set_prekick",
                   "o_ru_rf_cfg_lna_set_prekick",
                   # Alarm mibs
                   "o_ru_cali_status_active_tx_aclr_left_0", "o_ru_cali_status_active_tx_aclr_left_1",
                   "o_ru_cali_status_active_tx_aclr_left_2", "o_ru_cali_status_active_tx_aclr_left_3",
                   "o_ru_cali_status_active_tx_aclr_right_0", "o_ru_cali_status_active_tx_aclr_right_1",
                   "o_ru_cali_status_active_tx_aclr_right_2", "o_ru_cali_status_active_tx_aclr_right_3",
                   "o_ru_cali_status_active_tx_power_diff_0", "o_ru_cali_status_active_tx_power_diff_1",
                   "o_ru_cali_status_active_tx_power_diff_2", "o_ru_cali_status_active_tx_power_diff_3"]
    BOOT_POSITIVE_CHECK = ["DDRPHY: training success",
                           "mmc read OK",
                           "Verifying Hash Integrity ... sha256+ OK",
                           "Uncompressing Kernel Image",
                           "Loading Device Tree ",
                           "SBI specification v1.0 detected",
                           "SBI TIME extension detected",
                           "SBI IPI extension detected",
                           "SBI RFENCE extension detected",
                           "SBI SRST extension detected",
                           "SBI HSM extension detected",
                           "Trampoline variant of Tasks RCU enabled.",
                           "Tracing variant of Tasks RCU enabled.",
                           "SCSI subsystem initialized",
                           "usbcore: registered new interface driver usbfs",
                           "usbcore: registered new interface driver hub",
                           "usbcore: registered new device driver usb",
                           "PTP clock support registered",
                           "clocksource: Switched to clocksource riscv_clocksource",
                           "NET: Registered PF_UNIX/PF_LOCAL protocol family",
                           "io scheduler mq-deadline registered",
                           "io scheduler kyber registered",
                           "console [ttyS0] enabled",
                           "loop: module loaded",
                           "DMA HW capability register supported",
                           "RX Checksum Offload Engine supported",
                           "COE Type 1",
                           "TX Checksum insertion supported",
                           "Wake-Up On Lan supported",
                           "Enable RX Mitigation via HW Watchdog Timer",
                           "Enabled L3L4 Flow TC",
                           "Enabled RFS Flow TC",
                           "MDIO bus is disabled",
                           "XPCS/PMA setup completed",
                           "usbcore: registered new interface driver rtl8150",
                           "usbcore: registered new device driver r8152-cfgselector",
                           "usbcore: registered new interface driver r8152",
                           "usbcore: registered new interface driver asix",
                           "usbcore: registered new interface driver ax88179_178a",
                           "usbcore: registered new interface driver cdc_ether",
                           "usbcore: registered new interface driver dm9601",
                           "usbcore: registered new interface driver net1080",
                           "usbcore: registered new interface driver cdc_subset",
                           "usbcore: registered new interface driver zaurus",
                           "usbcore: registered new interface driver cdc_ncm",
                           "usbcore: registered new interface driver r8153_ecm",
                           "usbcore: registered new interface driver usb-storage",
                           "remoteproc remoteproc0: mras is available",
                           "riscv-pmu-sbi: SBI PMU extension is available",
                           "riscv-pmu-sbi: 16 firmware and 6 hardware counters",
                           "riscv-pmu-sbi: Andes HPM is available",
                           "NET: Registered PF_INET6 protocol family",
                           "VFS: Mounted root (squashfs filesystem) readonly on device",
                           "Run /init as init process",
                           "EXT4-fs (mmcblk0p8): recovery complete",
                           "EXT4-fs (mmcblk0p8): mounted filesystem with ordered data mode. Quota mode: disabled",
                           "Detected architecture riscv64",
                           "Finished Create List of Static Device Nodes",
                           "Finished Load Kernel Module configfs",
                           "Finished Load Kernel Module drm",
                           "Finished Load Kernel Module fuse",
                           "Finished Generate network units from Kernel command line",
                           "Finished Remount Root and Kernel File Systems",
                           "Finished Apply Kernel Variables",
                           "Mounted FUSE Control File System",
                           "Mounted Kernel Configuration File System",
                           "Finished Create Static Device Nodes in /dev gracefully",
                           "Finished Flush Journal to Persistent Storage",
                           "Finished Load/Save OS Random Seed",
                           "Finished load timestamp",
                           "Finished Coldplug All udev Devices",
                           "Finished Create Volatile Files and Directories",
                           "Finished Board-Info",
                           "Finished Record System Boot/Shutdown in UTMP",
                           "Finished Cobra INIT",
                           "Finished Virtual Console Setup",
                           "Finished Metanoia M-Plane Backend",
                           "Finished uEnv source policy",
                           "Finished Resets System Activity Logs",
                           "Finished Skyworks",
                           "Finished OpenSSH Key Generation",
                           "Finished Permit User Sessions",
                           "Finished AccuTime"]
    AP_RESET_CHECK = ["powering up mras",
                      "Booting fw image rproc-mras-fw",
                      "assigned reserved memory node vdev0buffer@",
                      "rpmsg host is online",
                      "registered virtio0 (type 7)",
                      "remote processor mras is now up",
                      "creating channel rpmsg-tty addr",
                      "creating channel rpmsg-raw addr"]
    AP_VERSION = {
        '1.0.1': '3.1.2.26021118061',
        '1.1.0' : '4.'
    }

nokia_1 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="xpath" xmlns:yanglib="urn:ietf:params:xml:ns:yang:ietf-yang-library" select="/yanglib:*"/></get>'''

nokia_2 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="xpath" xmlns:yanglib="urn:ietf:params:xml:ns:yang:ietf-yang-library" xmlns:yangmnt="urn:ietf:params:xml:ns:yang:ietf-yang-schema-mount" select="/yanglib:* | /yangmnt:*"/></get>'''

nokia_3 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><operational-info xmlns="urn:o-ran:operations:1.0"><declarations><supported-mplane-version/></declarations></operational-info></filter></get>'''

nokia_4 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><software-inventory xmlns="urn:o-ran:software-management:1.0"><software-slot><name/><status>VALID</status><running>true</running><product-code/><build-id/><build-name/><build-version/><vendor-code/></software-slot></software-inventory></filter></get>'''

nokia_5 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><hardware xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware"><component><name/><class xmlns:o-ran-hw="urn:o-ran:hardware:1.0">o-ran-hw:O-RAN-RADIO</class><serial-num/><mfg-name/><product-code xmlns="urn:o-ran:hardware:1.0"/></component></hardware></filter></get>'''

nokia_6 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="xpath" xmlns:yanglib="urn:ietf:params:xml:ns:yang:ietf-yang-library" select="/yanglib:*"/></get>'''

nokia_7 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><operational-info xmlns="urn:o-ran:operations:1.0"><operational-state/></operational-info></filter></get>'''

nokia_8 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"/>'''

nokia_11 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><ecpri-delay-message xmlns="urn:o-ran:message5:1.0"><two-step-t34-supported/></ecpri-delay-message></filter></get>'''

nokia_12 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><hardware xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware"><component><name/><class xmlns:o-ran-hw="urn:o-ran:hardware:1.0">o-ran-hw:O-RAN-RADIO</class><hardware-rev/><software-rev/><serial-num/><mfg-name/><model-name/><product-code xmlns="urn:o-ran:hardware:1.0"/><o-ran-name xmlns="urn:o-ran:hardware:1.0"/><energy-saving-enabled xmlns="urn:o-ran:hardware:1.0"/></component></hardware></filter></get>'''

nokia_13 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><fan-tray xmlns="urn:o-ran:fan:1.0"><fan-state/></fan-tray></filter></get>'''

nokia_14 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"><interface/></interfaces></filter></get>'''

nokia_15 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><module-capability xmlns="urn:o-ran:module-cap:1.0"><band-capabilities/></module-capability></filter></get>'''

nokia_16 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><module-capability xmlns="urn:o-ran:module-cap:1.0"><ru-capabilities><format-of-iq-sample><compression-method-supported/></format-of-iq-sample><coupling-methods><coupling-via-frequency-and-time/></coupling-methods><energy-saving-by-transmission-blanks/></ru-capabilities></module-capability></filter></get>'''

nokia_17 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><software-inventory xmlns="urn:o-ran:software-management:1.0"><software-slot/></software-inventory></filter></get>'''

nokia_18 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><port-transceivers xmlns="urn:o-ran:transceiver:1.0"><port-transceiver-data/></port-transceivers></filter></get>'''

nokia_19 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><tx-arrays/></user-plane-configuration></filter></get>'''

nokia_20 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><rx-arrays/></user-plane-configuration></filter></get>'''

nokia_21 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><endpoint-prach-group/></user-plane-configuration></filter></get>'''

nokia_22 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><port-transceivers xmlns="urn:o-ran:transceiver:1.0"><port-transceiver-data/></port-transceivers></filter></get>'''

nokia_23 = '''<retrieve-file-list xmlns="urn:o-ran:file-management:1.0"><logical-path>O-RAN/transceiver/</logical-path><file-name-filter>sfp_*.sffcap</file-name-filter></retrieve-file-list>'''

nokia_24 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><endpoint-types/></user-plane-configuration></filter></get>'''

nokia_25 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><static-low-level-tx-endpoints/></user-plane-configuration></filter></get>'''

nokia_26 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><static-low-level-rx-endpoints/></user-plane-configuration></filter></get>'''

nokia_27 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><fan-tray xmlns="urn:o-ran:fan:1.0"><fan-state/></fan-tray></filter></get>'''

nokia_28 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><ald-ports-io xmlns="urn:o-ran:ald-port:1.0"><ald-port/></ald-ports-io></filter></get>'''

nokia_29 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><external-io xmlns="urn:o-ran:external-io:1.0"><input/><output/></external-io></filter></get>'''

nokia_30 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><software-inventory xmlns="urn:o-ran:software-management:1.0"/></filter></get>'''

nokia_31 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><sync xmlns="urn:o-ran:sync:1.0"><sync-status/></sync></filter></get>'''

nokia_32 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><sync xmlns="urn:o-ran:sync:1.0"><ptp-config/></sync></filter></get>'''

nokia_33 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><sync xmlns="urn:o-ran:sync:1.0"><ptp-status><reporting-period/><lock-state/><clock-class/><clock-identity/><sources/></ptp-status></sync></filter></get>'''

nokia_34 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><sync xmlns="urn:o-ran:sync:1.0"><synce-config/></sync></filter></get>'''

nokia_35 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><sync xmlns="urn:o-ran:sync:1.0"><synce-status><reporting-period/><lock-state/><sources/></synce-status></sync></filter></get>'''

nokia_36 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><performance-measurement-objects xmlns="urn:o-ran:performance-management:1.0"><measurement-capabilitites/></performance-measurement-objects></filter></get>'''

nokia_37 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_38 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><performance-measurement-objects xmlns="urn:o-ran:performance-management:1.0"><notification-interval>3600</notification-interval></performance-measurement-objects></nc:config>'''

nokia_39 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_40 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><operational-info xmlns="urn:o-ran:operations:1.0"><operational-state><restart-cause/></operational-state></operational-info></filter></get>'''

nokia_41 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><hardware xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware"><component><name/><class xmlns:o-ran-hw="urn:o-ran:hardware:1.0">o-ran-hw:O-RAN-RADIO</class><state/></component></hardware></filter></get>'''

nokia_42 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><active-alarm-list xmlns="urn:o-ran:fm:1.0"/></filter></get>'''

nokia_43 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><delay-management xmlns="urn:o-ran:delay:1.0"><bandwidth-scs-delay-state/></delay-management></filter></get>'''

nokia_44 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_45 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><performance-measurement-objects xmlns="urn:o-ran:performance-management:1.0"><transceiver-measurement-interval>60</transceiver-measurement-interval><transceiver-measurement-objects><measurement-object>TEMPERATURE</measurement-object><active>true</active><report-info>LATEST</report-info><report-info>FIRST</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info><object-unit>PORT_NUMBER</object-unit><function>RAW</function></transceiver-measurement-objects><transceiver-measurement-objects><measurement-object>VOLTAGE</measurement-object><active>true</active><report-info>LATEST</report-info><report-info>FIRST</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info><object-unit>PORT_NUMBER</object-unit><function>RAW</function></transceiver-measurement-objects><transceiver-measurement-objects><measurement-object>TX_BIAS_COUNT</measurement-object><active>true</active><report-info>LATEST</report-info><report-info>FIRST</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info><object-unit>PORT_NUMBER</object-unit><function>RAW</function></transceiver-measurement-objects><transceiver-measurement-objects><measurement-object>TX_POWER</measurement-object><active>true</active><report-info>LATEST</report-info><report-info>FIRST</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info><object-unit>PORT_NUMBER</object-unit><function>RAW</function></transceiver-measurement-objects><transceiver-measurement-objects><measurement-object>RX_POWER</measurement-object><active>true</active><report-info>LATEST</report-info><report-info>FIRST</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info><object-unit>PORT_NUMBER</object-unit><function>RAW</function></transceiver-measurement-objects></performance-measurement-objects></nc:config>'''

nokia_47 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_48 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_49 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><performance-measurement-objects xmlns="urn:o-ran:performance-management:1.0"><epe-measurement-interval>60</epe-measurement-interval><epe-measurement-objects><measurement-object>CURRENT</measurement-object><active>true</active><report-info>AVERAGE</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info></epe-measurement-objects><epe-measurement-objects><measurement-object>VOLTAGE</measurement-object><active>true</active><report-info>AVERAGE</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info></epe-measurement-objects><epe-measurement-objects><measurement-object>POWER</measurement-object><active>true</active><report-info>AVERAGE</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info></epe-measurement-objects><epe-measurement-objects><measurement-object>TEMPERATURE</measurement-object><active>true</active><report-info>AVERAGE</report-info><report-info>MINIMUM</report-info><report-info>MAXIMUM</report-info></epe-measurement-objects></performance-measurement-objects></nc:config>'''

nokia_50 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_51 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><operational-info xmlns="urn:o-ran:operations:1.0"><operational-state><restart-datetime/></operational-state></operational-info></filter></get>'''

nokia_52 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><operational-info xmlns="urn:o-ran:operations:1.0"><operational-state><current-datetime/></operational-state></operational-info></filter></get>'''

nokia_53 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_54 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><sync xmlns="urn:o-ran:sync:1.0"><ptp-config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="replace"><domain-number>24</domain-number><accepted-clock-classes><clock-classes>7</clock-classes></accepted-clock-classes><accepted-clock-classes><clock-classes>6</clock-classes></accepted-clock-classes><ptp-profile>G_8275_1</ptp-profile><delay-asymmetry>0</delay-asymmetry><g-8275-1-config><multicast-mac-address>NONFORWARDABLE</multicast-mac-address></g-8275-1-config></ptp-config><ptp-status><reporting-period>60</reporting-period></ptp-status></sync></nc:config>'''

nokia_55 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_56 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><hardware xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware"><component><name/><class xmlns:o-ran-hw="urn:o-ran:hardware:1.0">o-ran-hw:O-RAN-RADIO</class><state/></component></hardware></filter></get>'''

nokia_57 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_58 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><mplane-info xmlns="urn:o-ran:mplane-interfaces:1.0"><searchable-mplane-access-vlans-info><vlan-range><lowest-vlan-id>1</lowest-vlan-id><highest-vlan-id>4094</highest-vlan-id></vlan-range></searchable-mplane-access-vlans-info></mplane-info></nc:config>'''

nokia_59 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"><interface><name>eth1</name><class-of-service xmlns="urn:o-ran:interfaces:1.0"><m-plane-marking>2</m-plane-marking></class-of-service></interface><interface><name>mpvlan2</name></interface><interface><name>vlan_301_eth1</name><ipv4 xmlns="urn:ietf:params:xml:ns:yang:ietf-ip"><m-plane-marking xmlns="urn:o-ran:interfaces:1.0">18</m-plane-marking></ipv4></interface></interfaces></nc:config>'''

nokia_60 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_61 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_62 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><ald-ports-io xmlns="urn:o-ran:ald-port:1.0"><ald-port-dc-control><name>aldPort2</name><dc-enabled>false</dc-enabled></ald-port-dc-control></ald-ports-io></nc:config>'''

nokia_63 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_66 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_67 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"><interface><name>vlan_301_eth1</name><description>VLAN IF for oRan eCPRI CU plane</description><type xmlns:ianaift="urn:ietf:params:xml:ns:yang:iana-if-type">ianaift:l2vlan</type><enabled>true</enabled><base-interface xmlns="urn:o-ran:interfaces:1.0">eth1</base-interface><vlan-id xmlns="urn:o-ran:interfaces:1.0">301</vlan-id><mac-address xmlns="urn:o-ran:interfaces:1.0">60:8f:a4:ef:d2:32</mac-address></interface></interfaces></nc:config>'''

nokia_68 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><interfaces xmlns="urn:ietf:params:xml:ns:yang:ietf-interfaces"><interface><name>eth1</name><class-of-service xmlns="urn:o-ran:interfaces:1.0"><u-plane-marking>7</u-plane-marking><c-plane-marking>7</c-plane-marking></class-of-service></interface></interfaces></nc:config>'''

nokia_69 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><processing-elements xmlns="urn:o-ran:processing-element:1.0" xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><transport-session-type>ETH-INTERFACE</transport-session-type><ru-elements><name>NR1.PE_1_vlan_301_eth1</name><transport-flow><interface-name>vlan_301_eth1</interface-name><eth-flow><ru-mac-address>60:8f:a4:ef:d2:32</ru-mac-address><vlan-id>301</vlan-id><o-du-mac-address>28:74:f5:2b:06:83</o-du-mac-address></eth-flow></transport-flow></ru-elements></processing-elements></nc:config>'''

nokia_70 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_72 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-tx-endpoints/><low-level-rx-endpoints/><low-level-tx-links/><low-level-rx-links/><tx-array-carriers/><rx-array-carriers/><static-prach-configurations/><configurable-tdd-patterns/></user-plane-configuration></filter></get>'''

nokia_73 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_76 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><tx-array-carriers xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.TX1_1_1_0</name><center-of-channel-bandwidth>3450000000</center-of-channel-bandwidth><channel-bandwidth>100000000</channel-bandwidth><active>INACTIVE</active><type>NR</type><gain>21.8466</gain><downlink-radio-frame-offset>0</downlink-radio-frame-offset><downlink-sfn-offset>0</downlink-sfn-offset><reference-level>16.1534</reference-level></tx-array-carriers></user-plane-configuration></nc:config>'''

nokia_77 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><rx-array-carriers xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RX1_1_1_0</name><center-of-channel-bandwidth>3450000000</center-of-channel-bandwidth><channel-bandwidth>100000000</channel-bandwidth><active>INACTIVE</active><type>NR</type><downlink-radio-frame-offset>0</downlink-radio-frame-offset><downlink-sfn-offset>0</downlink-sfn-offset><gain-correction>0.0</gain-correction><n-ta-offset>25600</n-ta-offset></rx-array-carriers></user-plane-configuration></nc:config>'''

nokia_78 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_79 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_80 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-ep0</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>0</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-ep1</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>1</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-ep2</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>2</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-ep3</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>3</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints></user-plane-configuration></nc:config>'''

nokia_80 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-prach-ep0</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>4</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-prach-ep1</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>5</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-prach-ep2</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>6</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints><low-level-rx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-rx-prach-ep3</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><ul-fft-sampling-offsets><scs>KHZ_30</scs><ul-fft-sampling-offset>16</ul-fft-sampling-offset></ul-fft-sampling-offsets><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>7</eaxc-id></e-axcid><non-time-managed-delay-enabled>false</non-time-managed-delay-enabled></low-level-rx-endpoints></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG0_CH0</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-ep2</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG0_CH1</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-ep0</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG0_CH2</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-ep1</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG0_CH3</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-ep3</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG1_CH0</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-prach-ep0</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG1_CH1</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-prach-ep1</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG1_CH2</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-prach-ep2</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_83 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG1_CH3</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-prach-ep3</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_81 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-tx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-tx-ep0</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>0</eaxc-id></e-axcid></low-level-tx-endpoints><low-level-tx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-tx-ep1</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>1</eaxc-id></e-axcid></low-level-tx-endpoints><low-level-tx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-tx-ep2</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>2</eaxc-id></e-axcid></low-level-tx-endpoints><low-level-tx-endpoints xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>meta-tx-ep3</name><compression><iq-bitwidth>9</iq-bitwidth><compression-type>STATIC</compression-type><compression-method>BLOCK_FLOATING_POINT</compression-method><fs-offset>16</fs-offset></compression><frame-structure>193</frame-structure><cp-type>NORMAL</cp-type><cp-length>88</cp-length><cp-length-other>72</cp-length-other><offset-to-absolute-frequency-center>-3276</offset-to-absolute-frequency-center><number-of-prb-per-scs><scs>KHZ_30</scs><number-of-prb>273</number-of-prb></number-of-prb-per-scs><e-axcid><o-du-port-bitmask>49152</o-du-port-bitmask><band-sector-bitmask>16128</band-sector-bitmask><ccid-bitmask>240</ccid-bitmask><ru-port-bitmask>15</ru-port-bitmask><eaxc-id>3</eaxc-id></e-axcid></low-level-tx-endpoints></user-plane-configuration></nc:config>'''

nokia_82 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-tx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.TLINK_CELL1_CG0_CH0</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><tx-array-carrier>NR1.TX1_1_1_0</tx-array-carrier><low-level-tx-endpoint>meta-tx-ep0</low-level-tx-endpoint></low-level-tx-links></user-plane-configuration></nc:config>'''

nokia_85 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-tx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.TLINK_CELL1_CG0_CH1</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><tx-array-carrier>NR1.TX1_1_1_0</tx-array-carrier><low-level-tx-endpoint>meta-tx-ep1</low-level-tx-endpoint></low-level-tx-links></user-plane-configuration></nc:config>'''

nokia_85 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-tx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.TLINK_CELL1_CG0_CH2</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><tx-array-carrier>NR1.TX1_1_1_0</tx-array-carrier><low-level-tx-endpoint>meta-tx-ep2</low-level-tx-endpoint></low-level-tx-links></user-plane-configuration></nc:config>'''

nokia_85 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-tx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.TLINK_CELL1_CG0_CH3</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><tx-array-carrier>NR1.TX1_1_1_0</tx-array-carrier><low-level-tx-endpoint>meta-tx-ep3</low-level-tx-endpoint></low-level-tx-links></user-plane-configuration></nc:config>'''

nokia_84 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG1_CH3</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-prach-ep2</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_87 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><low-level-rx-links xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0" nc:operation="merge"><name>NR1.RLINK_CELL1_CG1_CH6</name><processing-element>NR1.PE_1_vlan_301_eth1</processing-element><rx-array-carrier>NR1.RX1_1_1_0</rx-array-carrier><low-level-rx-endpoint>meta-rx-prach-ep0</low-level-rx-endpoint></low-level-rx-links></user-plane-configuration></nc:config>'''

nokia_89 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_90 = '''<lock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></lock>'''

nokia_91 = '''<nc:config xmlns:nc="urn:ietf:params:xml:ns:netconf:base:1.0"><user-plane-configuration xmlns="urn:o-ran:uplane-conf:1.0"><tx-array-carriers><name>NR1.TX1_1_1_0</name><active>ACTIVE</active></tx-array-carriers><rx-array-carriers><name>NR1.RX1_1_1_0</name><active>ACTIVE</active></rx-array-carriers></user-plane-configuration></nc:config>'''

nokia_92 = '''<unlock xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><target><running/></target></unlock>'''

nokia_93 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><hardware xmlns="urn:ietf:params:xml:ns:yang:ietf-hardware"><component><name/><class xmlns:o-ran-hw="urn:o-ran:hardware:1.0">o-ran-hw:O-RAN-RADIO</class><state/></component></hardware></filter></get>'''

nokia_94 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><port-transceivers xmlns="urn:o-ran:transceiver:1.0"><port-transceiver-data/></port-transceivers></filter></get>'''

nokia_95 = '''<file-upload xmlns="urn:o-ran:file-management:1.0"><local-logical-file-path>O-RAN/transceiver/sfp_0.sffcap</local-logical-file-path><remote-file-path>sftp://#####################@70.70.70.1/sfp_0.sffcap</remote-file-path><password><password>#####################</password></password><server><keys><algorithm>rsa2048</algorithm><public-key>AAAAB3NzaC1yc2EAAAADAQABAAABAQDOx3z3xGmL8rs9iDJMUbmm1y1zOh3/MPK99DfnzkWSxMhMZLnISK/75ZsEF+G1tozJ3A3tdreW69fdL+WutyuCQBgAf45ll5SWwZfqVV5xuEM9Vunws/Uu9Md2O8oAlCZIo8O+uaEMxLYAChUIIcbNqgFnNYos6cLOffJ+2s6B3WHCeNxNNpiiPNht1Tku+xaMaLn6D7lXNuYGmflPTjGmGMgGcStwyEQEgX0YRkILFCC073IOw53HIWlvUYL9L3Bc4hxv8uWay96FsifgGWI9jQ2oQXwRFzNZnL0O4SdH0jiKu5Rmoy/R/EJ1aGQHNLlzGFDytlmTIYCnaCvkYpjh</public-key></keys></server></file-upload>'''

nokia_97 = '''<get xmlns="urn:ietf:params:xml:ns:netconf:base:1.0"><filter type="subtree"><operational-info xmlns="urn:o-ran:operations:1.0"><operational-state><current-datetime/></operational-state></operational-info></filter></get>'''

nokia_99 = '''<start-troubleshooting-logs xmlns="urn:o-ran:troubleshooting:1.0"/>'''
