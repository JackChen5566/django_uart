# Bundled Python development runtime

For the standalone EXE, use `打包.bat` and follow [README-build.md](README-build.md). This document describes running the source code.

Double-click `StartGUI.bat` in the project root. A separate Python or pip installation is not required.

```text
qqa/
  StartGUI.bat
  runtime/python.exe
  runtime/Lib/site-packages/
  SW/Auto/GUI/QtGUI.py
```

- The runtime is official CPython 3.12.10 embeddable for Windows x64.
- Both the GUI and pytest use `runtime/python.exe`. Launching `QtGUI.py` directly also switches to this runtime.
- The fixed test is `SW/Auto/Script/Projects/Cobra/Cobra_LVDS_test_IC.py`. Change `TEST_FILE` near the top of `QtGUI.py` to select another file.
- Click **Initialize Configuration**, select **DutCom** and **DutCom1**, then click **Apply**. Configuration is stored at `C:\temp\auto_test_config\auto_config_cobra.yaml`.
- Enter an **Output folder name** before running. After completion or stopping and cleaning up child processes, all contents of `SW/Auto/test_log` are copied to `C:\temp\<output-folder-name>`. Subfolders and original logs are preserved.
- Existing filenames trigger an overwrite confirmation. Selecting **No** cancels the export. Another run cannot start during export.
- The pytest working directory is `SW`. Runtime search paths include the project root and `SW` so that `Auto` can be imported.
- Dependencies cover `requirements_win.txt`, `requirements_cobra_analog.txt`, psutil, and PyMySQL. Exact versions are in `SW/Auto/Package/requirements_runtime.lock.txt`.
- ncclient 0.6.19 avoids the unsupported Windows AF_UNIX import in version 0.6.16.
- Prepare any additional SDKs, hardware drivers, and external tools required by your tests.

## Copy to another computer

Copy the project and the complete `runtime` folder to a Windows x64 computer, preserving the layout above. The generated binary runtime is ignored by Git and is not included in a Git clone.

## Verify

```powershell
.\runtime\python.exe verify_runtime.py
```

Verification creates a hidden GUI and checks dependency imports, pytest execution, stopping pytest and its child processes, restarting, and log export. No UART hardware is required.

## Rebuild the runtime

On a build computer with Python 3.12 x64 and pip, move any existing runtime folder elsewhere, then run:

```powershell
.\prepare_runtime.ps1 -BuilderPython "C:\path\to\Python312\python.exe"
```

The script downloads the official Python runtime, verifies its pinned SHA256, and installs locked dependencies. Installation requires internet access. Routine GUI operation does not download packages.
