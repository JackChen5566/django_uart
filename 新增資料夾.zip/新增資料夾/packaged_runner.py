"""pytest entry point for tests compiled into the executable, not extracted .py files."""
import argparse
import importlib
import inspect
import os
from pathlib import Path
import tempfile

import pytest

SUITE_MODULE = "Auto.Script.Projects.Cobra.Cobra_LVDS_test_IC"


class CompiledSuitePlugin:
    def __init__(self, module, suite_path):
        self.module = module
        self.suite_path = suite_path

    def pytest_collect_file(self, file_path, parent):
        if file_path == self.suite_path:
            module = self.module

            class CompiledSuite(pytest.Module):
                def _getobj(self):
                    return module

            return CompiledSuite.from_parent(parent, path=file_path)

    @pytest.hookimpl(tryfirst=True)
    def pytest_pycollect_makeitem(self, collector, name, obj):
        # Nuitka functions are callable but are not inspect.isfunction objects.
        if (not inspect.isclass(obj) and not inspect.isfunction(obj)
                and callable(obj) and hasattr(obj, "__code__")
                and collector.funcnamefilter(name)
                and getattr(obj, "__test__", True)
                and not hasattr(obj, "_pytestfixturefunction")):
            return list(collector._genfunctions(name, obj))
        return None


def run_suite(module_name, work_directory, extra_args=()):
    module = importlib.import_module(module_name)
    # Only a collector marker goes on disk; no protected implementation is written.
    marker = work_directory / "test_compiled_suite.py"
    marker.write_text("# Tests are provided by the compiled collector.\n", encoding="utf-8")
    return int(pytest.main([
        str(marker), "--assert=plain", "--tb=short", "-q", "-s",
        "-o", "console_output_style=classic", *extra_args,
    ], plugins=[CompiledSuitePlugin(module, marker), "pytest_repeat"]))


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-tests", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--log-dir", type=Path)
    parser.add_argument("--auto-dir", type=Path)
    parser.add_argument("--collect-only", action="store_true")
    args = parser.parse_args(argv)
    os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    # Prevent workstation-specific pytest arguments from changing the native run.
    os.environ.pop("PYTEST_ADDOPTS", None)
    if args.self_test:
        with tempfile.TemporaryDirectory(prefix="TestTool-selftest-") as directory:
            work_directory = Path(directory)
            os.environ["TOOL_LOG_DIR"] = str(work_directory / "test_log")
            return run_suite("packaging_smoke_tests", work_directory)
    if not args.run_tests or args.log_dir is None or args.auto_dir is None:
        parser.error("--run-tests requires --log-dir and --auto-dir")
    log_directory = args.log_dir.resolve()
    log_directory.mkdir(parents=True, exist_ok=True)
    os.environ["TOOL_LOG_DIR"] = str(log_directory)
    os.environ["TOOL_AUTO_DIR"] = str(args.auto_dir.resolve())
    work_directory = log_directory.parent
    os.chdir(work_directory)
    return run_suite(SUITE_MODULE, work_directory, ["--collect-only"] if args.collect_only else [])


if __name__ == "__main__":
    raise SystemExit(main())
