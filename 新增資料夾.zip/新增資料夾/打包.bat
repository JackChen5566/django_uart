@echo off
setlocal
cd /d "%~dp0"
rem Optional: drag a full CPython 3.12 x64 python.exe onto this file,
rem or run: call "打包.bat" "C:\Python312\python.exe"
set "BUILD_PYTHON=%~1"
if defined BUILD_PYTHON goto build
for /f "delims=" %%P in ('py -3.12 -c "import sys; print(sys.executable)" 2^>nul') do set "BUILD_PYTHON=%%P"
if defined BUILD_PYTHON goto build
for /f "delims=" %%P in ('python -c "import sys; print(sys.executable)" 2^>nul') do set "BUILD_PYTHON=%%P"
if defined BUILD_PYTHON goto build
echo [ERROR] Install full CPython 3.12 x64 with pip on the build machine.
echo Then run this batch with the full path to its python.exe.
pause
exit /b 1

:build
"%BUILD_PYTHON%" "%~dp0build_exe.py"
if errorlevel 1 goto failed
echo.
echo [OK] Single-file release generated. See dist\Tool-*\Tool.exe
pause
exit /b 0

:failed
echo.
echo [ERROR] Build failed. See .build\logs and the output above.
pause
exit /b 1
